package ps.nexa.scan;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String BASE = "https://" + HOST + "/";
    private static final int REQ_CAMERA = 51, REQ_GALLERY = 52, REQ_STORAGE = 53;

    private WebView web;
    private final Handler main = new Handler(Looper.getMainLooper());
    private ValueCallback<Uri[]> fileCallback;
    private File cameraFile;
    private final Map<String, File> pending = new HashMap<>();
    private final Map<String, String> pendingMime = new HashMap<>();
    private JSONArray waitingSave;
    private android.widget.FrameLayout topArea;
    private android.widget.LinearLayout bottomArea;
    private android.widget.FrameLayout bannerBox;
    private Pro pro;
    private Ads ads;
    private boolean darkBars;
    private boolean night;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cleanCache();

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#F3F5F9"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serve(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openExternal(u.toString());
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                boolean ok = params.isCaptureEnabled() ? openCamera() : openGallery(params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                if (!ok) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                    toastJs("لا يوجد تطبيق مناسب على الجهاز");
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "Android");

        // layout: page on top, ad banner under it; edge-to-edge insets handled here
        topArea = new android.widget.FrameLayout(this);
        bottomArea = new android.widget.LinearLayout(this);
        bottomArea.setOrientation(android.widget.LinearLayout.VERTICAL);
        bannerBox = new android.widget.FrameLayout(this);
        bannerBox.setBackgroundColor(Color.parseColor("#F3F5F9"));
        bannerBox.setVisibility(View.GONE);
        bottomArea.addView(web, new android.widget.LinearLayout.LayoutParams(-1, 0, 1f));
        bottomArea.addView(bannerBox, new android.widget.LinearLayout.LayoutParams(-1, -2));
        topArea.addView(bottomArea, new android.widget.FrameLayout.LayoutParams(-1, -1));
        setContentView(topArea);
        setBars(false);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            topArea.setOnApplyWindowInsetsListener((v, in) -> {
                android.graphics.Insets b = in.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = in.getInsets(android.view.WindowInsets.Type.ime());
                topArea.setPadding(b.left, b.top, b.right, 0);
                bottomArea.setPadding(0, 0, 0, Math.max(b.bottom, ime.bottom));
                return android.view.WindowInsets.CONSUMED;
            });
        }
        if (Build.VERSION.SDK_INT >= 33) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, this::handleBack);
        }

        pro = new Pro(this, new Pro.Listener() {
            @Override
            public void onPro(boolean v) {
                main.post(() -> {
                    ads.setEnabled(!v);
                    web.evaluateJavascript("window.nexaPro && window.nexaPro(" + v + ")", null);
                });
            }

            @Override
            public void onPlans(String json) {
                main.post(() -> web.evaluateJavascript("window.nexaPlans && window.nexaPlans(" + JSONObject.quote(json) + ")", null));
            }

            @Override
            public void onMessage(String msg) { toastJs(msg); }
        });
        ads = new Ads(this, bannerBox);
        ads.setEnabled(!pro.isPro());
        ads.start();

        web.loadUrl(BASE + "index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pro != null) pro.refresh();
    }

    @Override
    protected void onDestroy() {
        if (ads != null) ads.destroy();
        super.onDestroy();
    }

    /* ---------- serving the web app from assets ---------- */

    private WebResourceResponse serve(Uri u) {
        if (u == null || !HOST.equals(u.getHost())) return null;
        String path = u.getPath() == null ? "/" : u.getPath();
        Map<String, String> headers = new HashMap<>();
        headers.put("Cache-Control", "no-store");
        try {
            String file = path.startsWith("/") ? path.substring(1) : path;
            if (file.isEmpty()) file = "index.html";
            InputStream in = getAssets().open(file);
            String m = mime(file);
            return new WebResourceResponse(m, m.startsWith("text") || file.endsWith(".js") || file.endsWith(".json") ? "utf-8" : null,
                    200, "OK", headers, in);
        } catch (Exception e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", headers,
                    new java.io.ByteArrayInputStream(new byte[0]));
        }
    }

    private static String mime(String file) {
        if (file.endsWith(".html")) return "text/html";
        if (file.endsWith(".js")) return "application/javascript";
        if (file.endsWith(".json")) return "application/json";
        if (file.endsWith(".css")) return "text/css";
        if (file.endsWith(".ttf")) return "font/ttf";
        if (file.endsWith(".svg")) return "image/svg+xml";
        String ext = MimeTypeMap.getFileExtensionFromUrl(file);
        String m = ext == null ? null : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m == null ? "application/octet-stream" : m;
    }

    /* ---------- camera & gallery ---------- */

    private boolean openCamera() {
        try {
            File dir = new File(getCacheDir(), "camera");
            dir.mkdirs();
            cameraFile = new File(dir, "shot_" + System.currentTimeMillis() + ".jpg");
            Uri out = FilesProvider.uriFor(cameraFile);
            Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            i.putExtra(MediaStore.EXTRA_OUTPUT, out);
            i.setClipData(ClipData.newRawUri("", out));
            i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i, REQ_CAMERA);
            return true;
        } catch (ActivityNotFoundException e) {
            return openGallery(false);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean openGallery(boolean multiple) {
        try {
            Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple);
            startActivityForResult(Intent.createChooser(i, "اختر الصور"), REQ_GALLERY);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAMERA && requestCode != REQ_GALLERY) return;
        ValueCallback<Uri[]> cb = fileCallback;
        fileCallback = null;
        if (cb == null) return;
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (requestCode == REQ_CAMERA) {
                if (cameraFile != null && cameraFile.exists() && cameraFile.length() > 0) {
                    result = new Uri[]{FilesProvider.uriFor(cameraFile)};
                }
            } else if (data != null) {
                ArrayList<Uri> list = new ArrayList<>();
                ClipData clip = data.getClipData();
                if (clip != null) {
                    for (int k = 0; k < clip.getItemCount(); k++) {
                        Uri u = clip.getItemAt(k).getUri();
                        if (u != null) list.add(u);
                    }
                } else if (data.getData() != null) {
                    list.add(data.getData());
                }
                if (!list.isEmpty()) result = list.toArray(new Uri[0]);
            }
        }
        cb.onReceiveValue(result);
    }

    /* ---------- saving & sharing ---------- */

    private File sharedDir() {
        File d = new File(getCacheDir(), "shared");
        d.mkdirs();
        return d;
    }

    private void cleanCache() {
        for (String name : new String[]{"shared", "camera"}) {
            File[] fs = new File(getCacheDir(), name).listFiles();
            if (fs == null) continue;
            long old = System.currentTimeMillis() - 24L * 3600 * 1000;
            for (File f : fs) if (f.lastModified() < old) f.delete();
        }
    }

    private static String cleanName(String n) {
        String s = n == null ? "" : n.replaceAll("[\\\\/:*?\"<>|\\n\\r]+", " ").trim();
        if (s.isEmpty() || s.startsWith(".")) s = "NEXA Scan";
        return s;
    }

    private void shareFiles(JSONArray ids) throws Exception {
        ArrayList<Uri> uris = new ArrayList<>();
        String type = null;
        for (int k = 0; k < ids.length(); k++) {
            File f = pending.get(ids.getString(k));
            if (f == null) continue;
            uris.add(FilesProvider.uriFor(f));
            String m = pendingMime.get(ids.getString(k));
            type = type == null ? m : (type.equals(m) ? type : "*/*");
        }
        if (uris.isEmpty()) return;
        Intent i;
        if (uris.size() == 1) {
            i = new Intent(Intent.ACTION_SEND);
            i.putExtra(Intent.EXTRA_STREAM, uris.get(0));
        } else {
            i = new Intent(Intent.ACTION_SEND_MULTIPLE);
            i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
        }
        i.setType(type);
        ClipData clip = ClipData.newRawUri("", uris.get(0));
        for (int k = 1; k < uris.size(); k++) clip.addItem(new ClipData.Item(uris.get(k)));
        i.setClipData(clip);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(i, "مشاركة"));
    }

    /** returns the number of files saved */
    private int saveFiles(JSONArray ids) throws Exception {
        int saved = 0;
        for (int k = 0; k < ids.length(); k++) {
            File f = pending.get(ids.getString(k));
            if (f == null) continue;
            String m = pendingMime.get(ids.getString(k));
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = getContentResolver();
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, f.getName());
                v.put(MediaStore.MediaColumns.MIME_TYPE, m);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/NEXA Scan");
                Uri u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) continue;
                try (OutputStream os = cr.openOutputStream(u); InputStream is = new FileInputStream(f)) {
                    copy(is, os);
                }
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "NEXA Scan");
                dir.mkdirs();
                File out = uniqueFile(dir, f.getName());
                try (OutputStream os = new FileOutputStream(out); InputStream is = new FileInputStream(f)) {
                    copy(is, os);
                }
                MediaScannerConnection.scanFile(this, new String[]{out.getAbsolutePath()}, new String[]{m}, null);
            }
            saved++;
        }
        return saved;
    }

    private static File uniqueFile(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name, ext = dot > 0 ? name.substring(dot) : "";
        for (int n = 1; ; n++) {
            f = new File(dir, base + " (" + n + ")" + ext);
            if (!f.exists()) return f;
        }
    }

    private static void copy(InputStream is, OutputStream os) throws Exception {
        byte[] buf = new byte[64 * 1024];
        int r;
        while ((r = is.read(buf)) > 0) os.write(buf, 0, r);
    }

    private String savedMessage(int n) {
        if (n <= 0) return "تعذّر حفظ الملف";
        return (n == 1 ? "تم حفظ الملف" : "تم حفظ " + n + " ملفات") + " في التنزيلات ← NEXA Scan";
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_STORAGE || waitingSave == null) return;
        JSONArray ids = waitingSave;
        waitingSave = null;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            try { toastJs(savedMessage(saveFiles(ids))); } catch (Exception e) { toastJs("تعذّر حفظ الملف"); }
        } else {
            toastJs("يلزم السماح بالوصول للتخزين لحفظ الملفات");
        }
    }

    private void toastJs(String msg) {
        main.post(() -> web.evaluateJavascript("window.nexaToast && window.nexaToast(" + JSONObject.quote(msg) + ")", null));
    }

    /* ---------- misc ---------- */

    private void setBars(boolean dark) {
        darkBars = dark;
        int top = Color.parseColor(dark ? "#0B1424" : night ? "#0F1D36" : "#16325C");
        int bottom = Color.parseColor(dark ? "#0B1424" : night ? "#0D1524" : "#F3F5F9");
        boolean lightNav = !dark && !night;
        if (topArea != null) topArea.setBackgroundColor(top);
        if (bottomArea != null) bottomArea.setBackgroundColor(bottom);
        if (Build.VERSION.SDK_INT < 35) {
            getWindow().setStatusBarColor(top);
            getWindow().setNavigationBarColor(bottom);
        }
        if (Build.VERSION.SDK_INT >= 30) {
            android.view.WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) c.setSystemBarsAppearance(lightNav ? android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS : 0,
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS | android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS);
        } else if (Build.VERSION.SDK_INT >= 26) {
            View d = getWindow().getDecorView();
            int f = d.getSystemUiVisibility();
            if (!lightNav) f &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            else f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            d.setSystemUiVisibility(f);
        }
        if (bannerBox != null) bannerBox.setBackgroundColor(bottom);
    }

    private void openExternal(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) { }
    }

    private void handleBack() {
        web.evaluateJavascript("(window.nexaBack && window.nexaBack()) ? 'y' : 'n'", value -> {
            if (value == null || !value.contains("y")) finish();
        });
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        handleBack();
    }

    /* ---------- bridge used by app.js ---------- */

    class Bridge {
        @JavascriptInterface
        public String beginFile(String name, String mime) {
            String id = Long.toString(System.nanoTime(), 36);
            File f = new File(sharedDir(), cleanName(name));
            f.delete();
            synchronized (pending) {
                pending.put(id, f);
                pendingMime.put(id, mime);
            }
            return id;
        }

        @JavascriptInterface
        public void appendChunk(String id, String b64) {
            File f;
            synchronized (pending) { f = pending.get(id); }
            if (f == null) return;
            try (FileOutputStream os = new FileOutputStream(f, true)) {
                os.write(Base64.decode(b64, Base64.DEFAULT));
            } catch (Exception ignored) { }
        }

        @JavascriptInterface
        public String finishFiles(String idsJson, String mode) {
            try {
                JSONArray ids = new JSONArray(idsJson);
                if ("share".equals(mode)) {
                    main.post(() -> {
                        try { shareFiles(ids); } catch (Exception e) { toastJs("تعذّرت المشاركة"); }
                    });
                    return "";
                }
                if (Build.VERSION.SDK_INT < 29 &&
                        checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    waitingSave = ids;
                    main.post(() -> requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE));
                    return "";
                }
                return savedMessage(saveFiles(ids));
            } catch (Exception e) {
                return "تعذّر حفظ الملف";
            }
        }

        @JavascriptInterface
        public void setDark(boolean dark) {
            main.post(() -> setBars(dark));
        }

        @JavascriptInterface
        public boolean isPro() { return pro.isPro(); }

        @JavascriptInterface
        public String plans() { return pro.plans(); }

        @JavascriptInterface
        public void buy(String plan) { pro.buy(plan); }

        @JavascriptInterface
        public boolean redeem(String code) { return pro.redeem(code); }

        @JavascriptInterface
        public void restore() {
            main.post(() -> pro.refresh());
        }

        @JavascriptInterface
        public void manageSubscription() {
            main.post(() -> openExternal("https://play.google.com/store/account/subscriptions?sku=" + Pro.PRODUCT + "&package=" + getPackageName()));
        }

        @JavascriptInterface
        public boolean showInterstitial() {
            final boolean[] shown = {false};
            java.util.concurrent.CountDownLatch l = new java.util.concurrent.CountDownLatch(1);
            main.post(() -> { shown[0] = ads.showInterstitial(); l.countDown(); });
            try { l.await(2, java.util.concurrent.TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
            return shown[0];
        }

        @JavascriptInterface
        public boolean privacyNeeded() { return ads.privacyNeeded(); }

        @JavascriptInterface
        public void privacyOptions() { main.post(() -> ads.privacyOptions()); }

        @JavascriptInterface
        public void setNight(boolean n) {
            main.post(() -> { night = n; setBars(darkBars); web.setBackgroundColor(Color.parseColor(n ? "#0D1524" : "#F3F5F9")); });
        }

        @JavascriptInterface
        public void openUrl(String url) {
            main.post(() -> openExternal(url));
        }
    }
}
