package ps.nexa.scan;

import android.app.Activity;
import android.content.SharedPreferences;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import org.json.JSONObject;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Google Play subscription "nexa_scan_pro" with base plans "monthly" and "yearly". */
public class Pro implements PurchasesUpdatedListener {

    public static final String PRODUCT = "nexa_scan_pro";

    public interface Listener {
        void onPro(boolean pro);
        void onPlans(String json);
        void onMessage(String msg);
    }

    private final Activity act;
    private final Listener listener;
    private final SharedPreferences prefs;
    private final BillingClient client;
    private ProductDetails details;
    private final Map<String, String> tokens = new HashMap<>();
    private String plansJson = "";
    /** last billing problem: "", or a short code the page turns into a message */
    private volatile String status = "connecting";
    private boolean pro;
    private boolean review;
    private boolean connecting;
    /** access code for Google Play reviewers (given in Play Console > App access) */
    private static final String REVIEW_CODE = "NXS-REVIEW-4827";

    public Pro(Activity a, Listener l) {
        act = a;
        listener = l;
        prefs = a.getSharedPreferences("pro", Activity.MODE_PRIVATE);
        pro = prefs.getBoolean("pro", false);
        review = prefs.getBoolean("review", false);
        client = BillingClient.newBuilder(a)
                .setListener(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .build();
        connect();
    }

    public boolean isPro() { return pro || review; }

    /** unlocks Pro on this device for app review; returns true if the code is right */
    public boolean redeem(String code) {
        if (code == null || !REVIEW_CODE.equalsIgnoreCase(code.trim())) return false;
        boolean was = isPro();
        review = true;
        prefs.edit().putBoolean("review", true).apply();
        if (!was) listener.onPro(true);
        return true;
    }

    public String plans() { return plansJson; }

    public String status() { return status; }

    /** called when the Pro screen opens: reconnect and ask Play again */
    public void reload() {
        act.runOnUiThread(() -> {
            if (!client.isReady()) { status = "connecting"; connect(); }
            else loadDetails();
        });
    }

    private static String code(int c) {
        switch (c) {
            case BillingClient.BillingResponseCode.BILLING_UNAVAILABLE: return "unavailable";
            case BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE:
            case BillingClient.BillingResponseCode.SERVICE_DISCONNECTED:
            case BillingClient.BillingResponseCode.NETWORK_ERROR: return "network";
            case BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED: return "unsupported";
            case BillingClient.BillingResponseCode.DEVELOPER_ERROR: return "developer";
            default: return "error" + c;
        }
    }

    private void connect() {
        if (client.isReady() || connecting) return;
        connecting = true;
        client.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult r) {
                connecting = false;
                if (r.getResponseCode() != BillingClient.BillingResponseCode.OK) status = code(r.getResponseCode());
                if (r.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    status = "loading";
                    refresh();
                    loadDetails();
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                connecting = false;
                status = "network";
            }
        });
    }

    /** re-reads active subscriptions from Play */
    public void refresh() {
        if (!client.isReady()) { connect(); return; }
        client.queryPurchasesAsync(
                QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build(),
                (r, list) -> {
                    if (r.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
                    boolean has = false;
                    for (Purchase p : list) {
                        if (p.getProducts().contains(PRODUCT) && p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                            has = true;
                            acknowledge(p);
                        }
                    }
                    setPro(has);
                });
    }

    private void loadDetails() {
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(Collections.singletonList(QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(PRODUCT).setProductType(BillingClient.ProductType.SUBS).build()))
                .build();
        client.queryProductDetailsAsync(params, (r, result) -> {
            List<ProductDetails> list = result == null ? null : result.getProductDetailsList();
            if (r.getResponseCode() != BillingClient.BillingResponseCode.OK) { status = code(r.getResponseCode()); return; }
            if (list == null || list.isEmpty()) { status = "noproduct"; return; }
            details = list.get(0);
            buildPlans();
        });
    }

    private void buildPlans() {
        try {
            List<ProductDetails.SubscriptionOfferDetails> offers = details.getSubscriptionOfferDetails();
            if (offers == null) return;
            JSONObject out = new JSONObject();
            tokens.clear();
            for (String plan : new String[]{"monthly", "yearly"}) {
                ProductDetails.SubscriptionOfferDetails base = null, trial = null;
                for (ProductDetails.SubscriptionOfferDetails o : offers) {
                    if (!plan.equals(o.getBasePlanId())) continue;
                    if (o.getOfferId() == null) base = o;
                    else {
                        for (ProductDetails.PricingPhase ph : o.getPricingPhases().getPricingPhaseList()) {
                            if (ph.getPriceAmountMicros() == 0) { trial = o; break; }
                        }
                    }
                }
                ProductDetails.SubscriptionOfferDetails use = trial != null ? trial : base;
                if (use == null) continue;
                List<ProductDetails.PricingPhase> phases = use.getPricingPhases().getPricingPhaseList();
                ProductDetails.PricingPhase full = phases.get(phases.size() - 1);
                JSONObject j = new JSONObject();
                j.put("price", full.getFormattedPrice());
                j.put("micros", full.getPriceAmountMicros());
                j.put("currency", full.getPriceCurrencyCode());
                j.put("trial", trial != null);
                out.put(plan, j);
                tokens.put(plan, use.getOfferToken());
            }
            plansJson = out.toString();
            status = out.length() == 0 ? "noplans" : "";
            listener.onPlans(plansJson);
        } catch (Exception ignored) { }
    }

    public void buy(String plan) {
        act.runOnUiThread(() -> {
            if (!client.isReady() || details == null || !tokens.containsKey(plan)) {
                connect();
                listener.onMessage("تعذّر الاتصال بمتجر Google Play، تأكد من الإنترنت وحاول مرة أخرى");
                return;
            }
            BillingFlowParams.ProductDetailsParams p = BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(details).setOfferToken(tokens.get(plan)).build();
            client.launchBillingFlow(act, BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(Collections.singletonList(p)).build());
        });
    }

    @Override
    public void onPurchasesUpdated(BillingResult r, List<Purchase> purchases) {
        int code = r.getResponseCode();
        if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
            boolean ok = false;
            for (Purchase p : purchases) {
                if (!p.getProducts().contains(PRODUCT)) continue;
                if (p.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    acknowledge(p);
                    ok = true;
                } else if (p.getPurchaseState() == Purchase.PurchaseState.PENDING) {
                    listener.onMessage("الدفع قيد المعالجة، سيتم تفعيل Pro تلقائياً عند اكتماله");
                }
            }
            if (ok) {
                setPro(true);
                listener.onMessage("تم تفعيل NEXA Scan Pro، شكراً لك");
            }
        } else if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            refresh();
            listener.onMessage("اشتراكك مفعّل بالفعل");
        } else if (code != BillingClient.BillingResponseCode.USER_CANCELED) {
            listener.onMessage("لم تكتمل عملية الاشتراك، حاول مرة أخرى");
        }
    }

    private void acknowledge(Purchase p) {
        if (p.isAcknowledged()) return;
        client.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(p.getPurchaseToken()).build(), r -> { });
    }

    private void setPro(boolean v) {
        boolean was = isPro();
        pro = v;
        prefs.edit().putBoolean("pro", v).apply();
        if (was != isPro()) listener.onPro(isPro());
    }
}
