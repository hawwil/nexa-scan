package ps.nexa.scan;

import android.app.Activity;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.FrameLayout;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.ump.ConsentInformation;
import com.google.android.ump.ConsentRequestParameters;
import com.google.android.ump.UserMessagingPlatform;

import java.util.concurrent.atomic.AtomicBoolean;

/** AdMob banner + interstitial for the free version, with the Google consent form where required. */
public class Ads {

    private final Activity act;
    private final FrameLayout box;
    private final ConsentInformation consent;
    private final AtomicBoolean started = new AtomicBoolean(false);
    private boolean ready;
    private boolean enabled;
    private AdView banner;
    private InterstitialAd inter;

    public Ads(Activity a, FrameLayout bannerBox) {
        act = a;
        box = bannerBox;
        consent = UserMessagingPlatform.getConsentInformation(a);
    }

    public void start() {
        consent.requestConsentInfoUpdate(act, new ConsentRequestParameters.Builder().build(),
                () -> UserMessagingPlatform.loadAndShowConsentFormIfRequired(act, err -> {
                    if (consent.canRequestAds()) init();
                }),
                err -> { if (consent.canRequestAds()) init(); });
        if (consent.canRequestAds()) init();
    }

    private void init() {
        if (started.getAndSet(true)) return;
        new Thread(() -> MobileAds.initialize(act, s -> act.runOnUiThread(() -> {
            ready = true;
            if (enabled) { loadBanner(); loadInter(); }
        }))).start();
    }

    public void setEnabled(boolean e) {
        enabled = e;
        if (!e) {
            box.setVisibility(View.GONE);
            if (banner != null) { box.removeAllViews(); banner.destroy(); banner = null; }
            inter = null;
        } else if (ready) {
            loadBanner();
            if (inter == null) loadInter();
        }
    }

    private void loadBanner() {
        if (banner != null) { box.setVisibility(View.VISIBLE); return; }
        DisplayMetrics dm = act.getResources().getDisplayMetrics();
        int widthDp = (int) (dm.widthPixels / dm.density);
        banner = new AdView(act);
        banner.setAdUnitId(BuildConfig.AD_BANNER);
        banner.setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(act, widthDp));
        box.addView(banner, new FrameLayout.LayoutParams(-1, -2));
        box.setVisibility(View.VISIBLE);
        banner.loadAd(new AdRequest.Builder().build());
    }

    private void loadInter() {
        InterstitialAd.load(act, BuildConfig.AD_INTERSTITIAL, new AdRequest.Builder().build(),
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(InterstitialAd ad) { inter = ad; }

                    @Override
                    public void onAdFailedToLoad(LoadAdError e) { inter = null; }
                });
    }

    /** shows a full-screen ad if one is ready; returns false otherwise */
    public boolean showInterstitial() {
        if (!enabled || inter == null) return false;
        InterstitialAd ad = inter;
        inter = null;
        ad.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() { if (enabled) loadInter(); }

            @Override
            public void onAdFailedToShowFullScreenContent(AdError e) { if (enabled) loadInter(); }
        });
        ad.show(act);
        return true;
    }

    public boolean privacyNeeded() {
        return consent.getPrivacyOptionsRequirementStatus() == ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED;
    }

    public void privacyOptions() {
        UserMessagingPlatform.showPrivacyOptionsForm(act, err -> { });
    }

    public void destroy() {
        if (banner != null) banner.destroy();
    }
}
