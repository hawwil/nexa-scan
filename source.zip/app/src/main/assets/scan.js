/* NEXA Scan — image engine: document detection, perspective correction, filters, PDF.
   Works on plain {data,width,height} RGBA buffers, no external libraries. */
(function (root) {
  'use strict';

  /* ---------------- helpers ---------------- */

  function toGray(img) {
    const { data, width, height } = img;
    const g = new Float32Array(width * height);
    for (let i = 0, p = 0; i < g.length; i++, p += 4) {
      g[i] = 0.299 * data[p] + 0.587 * data[p + 1] + 0.114 * data[p + 2];
    }
    return g;
  }

  function boxBlur(src, w, h, r) {
    if (r < 1) return src.slice();
    const tmp = new Float32Array(w * h), out = new Float32Array(w * h);
    const d = 2 * r + 1;
    for (let y = 0; y < h; y++) {
      const row = y * w;
      let acc = 0;
      for (let x = -r; x <= r; x++) acc += src[row + Math.min(w - 1, Math.max(0, x))];
      for (let x = 0; x < w; x++) {
        tmp[row + x] = acc / d;
        const add = Math.min(w - 1, x + r + 1), rem = Math.max(0, x - r);
        acc += src[row + add] - src[row + rem];
      }
    }
    for (let x = 0; x < w; x++) {
      let acc = 0;
      for (let y = -r; y <= r; y++) acc += tmp[Math.min(h - 1, Math.max(0, y)) * w + x];
      for (let y = 0; y < h; y++) {
        out[y * w + x] = acc / d;
        const add = Math.min(h - 1, y + r + 1), rem = Math.max(0, y - r);
        acc += tmp[add * w + x] - tmp[rem * w + x];
      }
    }
    return out;
  }

  function otsu(values, max) {
    const bins = 256, hist = new Float64Array(bins);
    const scale = (bins - 1) / (max || 1);
    for (let i = 0; i < values.length; i++) hist[Math.min(bins - 1, Math.max(0, Math.round(values[i] * scale)))]++;
    let total = values.length, sum = 0;
    for (let i = 0; i < bins; i++) sum += i * hist[i];
    let sumB = 0, wB = 0, best = 0, thr = 0;
    for (let i = 0; i < bins; i++) {
      wB += hist[i];
      if (!wB) continue;
      const wF = total - wB;
      if (!wF) break;
      sumB += i * hist[i];
      const mB = sumB / wB, mF = (sum - sumB) / wF;
      const v = wB * wF * (mB - mF) * (mB - mF);
      if (v > best) { best = v; thr = i; }
    }
    return thr / scale;
  }

  function percentile(values, p) {
    const s = Float32Array.from(values).sort();
    return s[Math.min(s.length - 1, Math.floor(p * s.length))];
  }

  function dilate(mask, w, h, r) {
    let cur = mask;
    for (let k = 0; k < r; k++) {
      const out = new Uint8Array(w * h);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        const i = y * w + x;
        if (cur[i] || (x > 0 && cur[i - 1]) || (x < w - 1 && cur[i + 1]) ||
            (y > 0 && cur[i - w]) || (y < h - 1 && cur[i + w])) out[i] = 1;
      }
      cur = out;
    }
    return cur;
  }

  function erode(mask, w, h, r) {
    let cur = mask;
    for (let k = 0; k < r; k++) {
      const out = new Uint8Array(w * h);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        const i = y * w + x;
        if (cur[i] && x > 0 && cur[i - 1] && x < w - 1 && cur[i + 1] &&
            y > 0 && cur[i - w] && y < h - 1 && cur[i + w]) out[i] = 1;
      }
      cur = out;
    }
    return cur;
  }

  /* flood fill from the image border over pixels where pass[i] is 1; returns reached map */
  function floodFromBorder(pass, w, h) {
    const seen = new Uint8Array(w * h);
    const stack = new Int32Array(w * h);
    let sp = 0;
    const push = (i) => { if (pass[i] && !seen[i]) { seen[i] = 1; stack[sp++] = i; } };
    for (let x = 0; x < w; x++) { push(x); push((h - 1) * w + x); }
    for (let y = 0; y < h; y++) { push(y * w); push(y * w + w - 1); }
    while (sp) {
      const i = stack[--sp], x = i % w, y = (i - x) / w;
      if (x > 0) push(i - 1);
      if (x < w - 1) push(i + 1);
      if (y > 0) push(i - w);
      if (y < h - 1) push(i + w);
    }
    return seen;
  }

  /* largest 4-connected component of mask; returns {pixels:Int32Array, count} */
  function largestComponent(mask, w, h) {
    const label = new Int32Array(w * h);
    const stack = new Int32Array(w * h);
    let bestId = 0, bestCount = 0, id = 0;
    for (let s = 0; s < mask.length; s++) {
      if (!mask[s] || label[s]) continue;
      id++;
      let sp = 0, count = 0;
      label[s] = id; stack[sp++] = s;
      while (sp) {
        const i = stack[--sp], x = i % w;
        count++;
        if (x > 0 && mask[i - 1] && !label[i - 1]) { label[i - 1] = id; stack[sp++] = i - 1; }
        if (x < w - 1 && mask[i + 1] && !label[i + 1]) { label[i + 1] = id; stack[sp++] = i + 1; }
        if (i >= w && mask[i - w] && !label[i - w]) { label[i - w] = id; stack[sp++] = i - w; }
        if (i < w * (h - 1) && mask[i + w] && !label[i + w]) { label[i + w] = id; stack[sp++] = i + w; }
      }
      if (count > bestCount) { bestCount = count; bestId = id; }
    }
    if (!bestId) return null;
    const out = new Uint8Array(w * h);
    for (let i = 0; i < label.length; i++) if (label[i] === bestId) out[i] = 1;
    return { mask: out, count: bestCount };
  }

  function fillHoles(mask, w, h) {
    const inv = new Uint8Array(w * h);
    for (let i = 0; i < inv.length; i++) inv[i] = mask[i] ? 0 : 1;
    const outside = floodFromBorder(inv, w, h);
    const out = new Uint8Array(w * h);
    let n = 0;
    for (let i = 0; i < out.length; i++) if (mask[i] || !outside[i]) { out[i] = 1; n++; }
    return { mask: out, count: n };
  }

  /* boundary points of a mask (pixels with a 0 neighbour) */
  function boundaryPoints(mask, w, h) {
    const pts = [];
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const i = y * w + x;
      if (!mask[i]) continue;
      if (x === 0 || y === 0 || x === w - 1 || y === h - 1 ||
          !mask[i - 1] || !mask[i + 1] || !mask[i - w] || !mask[i + w]) pts.push([x + 0.5, y + 0.5]);
    }
    return pts;
  }

  function convexHull(pts) {
    if (pts.length < 3) return pts.slice();
    const p = pts.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
    const lower = [];
    for (const q of p) {
      while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], q) <= 0) lower.pop();
      lower.push(q);
    }
    const upper = [];
    for (let i = p.length - 1; i >= 0; i--) {
      const q = p[i];
      while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], q) <= 0) upper.pop();
      upper.push(q);
    }
    upper.pop(); lower.pop();
    return lower.concat(upper);
  }

  function polyArea(poly) {
    let a = 0;
    for (let i = 0; i < poly.length; i++) {
      const p = poly[i], q = poly[(i + 1) % poly.length];
      a += p[0] * q[1] - q[0] * p[1];
    }
    return Math.abs(a) / 2;
  }

  /* largest-area quadrilateral with vertices on the convex hull */
  function maxQuad(hull) {
    const n = hull.length;
    if (n < 4) return null;
    const tri = (a, b, c) => Math.abs((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])) / 2;
    // start from the extreme points
    let idx = [0, 0, 0, 0];
    const f = [(p) => -(p[0] + p[1]), (p) => p[0] - p[1], (p) => p[0] + p[1], (p) => -(p[0] - p[1])];
    for (let k = 0; k < 4; k++) {
      let best = -Infinity;
      for (let i = 0; i < n; i++) { const v = f[k](hull[i]); if (v > best) { best = v; idx[k] = i; } }
    }
    idx.sort((a, b) => a - b);
    if (new Set(idx).size < 4) {
      idx = [0, Math.floor(n / 4), Math.floor(n / 2), Math.floor(3 * n / 4)];
    }
    let improved = true, guard = 0;
    while (improved && guard++ < 50) {
      improved = false;
      for (let k = 0; k < 4; k++) {
        const prev = idx[(k + 3) % 4], next = idx[(k + 1) % 4];
        let bestI = idx[k], bestA = tri(hull[prev], hull[idx[k]], hull[next]);
        for (let i = (prev + 1) % n; i !== next; i = (i + 1) % n) {
          const a = tri(hull[prev], hull[i], hull[next]);
          if (a > bestA + 1e-9) { bestA = a; bestI = i; }
        }
        if (bestI !== idx[k]) { idx[k] = bestI; improved = true; }
      }
    }
    return idx.map((i) => hull[i]);
  }

  /* order as top-left, top-right, bottom-right, bottom-left */
  function orderQuad(q) {
    const c = q.reduce((a, p) => [a[0] + p[0] / 4, a[1] + p[1] / 4], [0, 0]);
    const s = q.slice().sort((a, b) => Math.atan2(a[1] - c[1], a[0] - c[0]) - Math.atan2(b[1] - c[1], b[0] - c[0]));
    // s is clockwise starting from angle -pi (left). find top-left = min x+y
    let start = 0, best = Infinity;
    for (let i = 0; i < 4; i++) { const v = s[i][0] + s[i][1]; if (v < best) { best = v; start = i; } }
    return [0, 1, 2, 3].map((k) => s[(start + k) % 4]);
  }

  function evaluate(mask, count, w, h) {
    if (!mask || count < w * h * 0.08) return null;
    const hull = convexHull(boundaryPoints(mask, w, h));
    const q = maxQuad(hull);
    if (!q) return null;
    const qa = polyArea(q), ha = polyArea(hull);
    const ratio = qa / (w * h);
    const fill = Math.min(count, qa) / Math.max(count, qa);
    const quadness = qa / ha;
    if (ratio < 0.1 || fill < 0.75 || quadness < 0.85) return null;
    // penalise shapes that simply hug the whole frame
    const oq = orderQuad(q), mw = w * 0.05, mh = h * 0.05;
    const corners = [[0, 0], [w, 0], [w, h], [0, h]];
    const hugs = oq.every((p, i) => Math.abs(p[0] - corners[i][0]) < mw && Math.abs(p[1] - corners[i][1]) < mh);
    const frame = hugs ? 0.2 : ratio > 0.92 ? 0.6 : 1;
    return { quad: oq, score: ratio * fill * fill * quadness * frame };
  }

  /* Detect the document in a small image (≈ 400px). Returns {quad:[[x,y]x4] in that image's px, found} */
  function detect(img) {
    const { width: w, height: h, data } = img;
    const gray = boxBlur(toGray(img), w, h, 1);
    const cands = [];

    // A) colour distance from the border background
    {
      const bw = Math.max(2, Math.round(Math.min(w, h) * 0.04));
      const rs = [], gs = [], bs = [];
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        if (x >= bw && y >= bw && x < w - bw && y < h - bw) continue;
        const p = (y * w + x) * 4; rs.push(data[p]); gs.push(data[p + 1]); bs.push(data[p + 2]);
      }
      const med = (a) => { a.sort((u, v) => u - v); return a[a.length >> 1]; };
      const br = med(rs), bg = med(gs), bb = med(bs);
      let dist = new Float32Array(w * h);
      for (let i = 0, p = 0; i < dist.length; i++, p += 4) {
        const dr = data[p] - br, dg = data[p + 1] - bg, db = data[p + 2] - bb;
        dist[i] = Math.sqrt(dr * dr + dg * dg + db * db);
      }
      dist = boxBlur(dist, w, h, 2);
      // background noise level from the border strip
      const bd = [];
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        if (x >= bw && y >= bw && x < w - bw && y < h - bw) continue;
        bd.push(dist[y * w + x]);
      }
      bd.sort((u, v) => u - v);
      const noise = bd[Math.floor(bd.length * 0.9)] || 10;
      const t0 = otsu(dist, 442);
      const ths = [Math.max(28, t0), Math.max(noise * 1.6, t0 * 0.55), Math.max(noise * 1.3, 14)];
      for (const t of ths) {
        let m = new Uint8Array(w * h);
        for (let i = 0; i < m.length; i++) m[i] = dist[i] > t ? 1 : 0;
        m = erode(dilate(m, w, h, 2), w, h, 2);
        m = erode(m, w, h, 1); // detach thin touching objects
        const lc = largestComponent(m, w, h);
        if (lc) {
          const fh = fillHoles(dilate(lc.mask, w, h, 1), w, h);
          const e = evaluate(fh.mask, fh.count, w, h);
          if (e) cands.push(e);
        }
      }
    }

    // B) brightness (paper is usually lighter than the surface)
    {
      const t = otsu(gray, 255);
      let m = new Uint8Array(w * h);
      for (let i = 0; i < m.length; i++) m[i] = gray[i] > t ? 1 : 0;
      m = erode(dilate(m, w, h, 2), w, h, 3);
      const lc = largestComponent(m, w, h);
      if (lc) {
        const fh = fillHoles(dilate(lc.mask, w, h, 1), w, h);
        const e = evaluate(fh.mask, fh.count, w, h);
        if (e) cands.push(e);
      }
    }

    // C) closed edge contour
    {
      const mag = new Float32Array(w * h);
      for (let y = 1; y < h - 1; y++) for (let x = 1; x < w - 1; x++) {
        const i = y * w + x;
        const gx = gray[i - w + 1] + 2 * gray[i + 1] + gray[i + w + 1] - gray[i - w - 1] - 2 * gray[i - 1] - gray[i + w - 1];
        const gy = gray[i + w - 1] + 2 * gray[i + w] + gray[i + w + 1] - gray[i - w - 1] - 2 * gray[i - w] - gray[i - w + 1];
        mag[i] = Math.hypot(gx, gy);
      }
      const t = Math.max(40, percentile(mag, 0.88));
      let edge = new Uint8Array(w * h);
      for (let i = 0; i < edge.length; i++) edge[i] = mag[i] > t ? 1 : 0;
      edge = dilate(edge, w, h, 1);
      const pass = new Uint8Array(w * h);
      for (let i = 0; i < pass.length; i++) pass[i] = edge[i] ? 0 : 1;
      const out = floodFromBorder(pass, w, h);
      const inside = new Uint8Array(w * h);
      for (let i = 0; i < inside.length; i++) inside[i] = out[i] ? 0 : 1;
      const lc = largestComponent(erode(inside, w, h, 1), w, h);
      if (lc) {
        const fh = fillHoles(lc.mask, w, h);
        const e = evaluate(fh.mask, fh.count, w, h);
        if (e) cands.push(e);
      }
    }

    if (!cands.length) {
      const mx = w * 0.06, my = h * 0.06;
      return { found: false, quad: [[mx, my], [w - mx, my], [w - mx, h - my], [mx, h - my]] };
    }
    cands.sort((a, b) => b.score - a.score);
    const q = cands[0].quad, c = q.reduce((a, p) => [a[0] + p[0] / 4, a[1] + p[1] / 4], [0, 0]);
    return { found: true, quad: q.map((p) => [p[0] + (c[0] - p[0]) * 0.008, p[1] + (c[1] - p[1]) * 0.008]) };
  }

  /* Refine a rough quad on a larger image: snap every side to the strongest edge near it. */
  function refine(img, quad) {
    const { width: w, height: h } = img;
    const g = boxBlur(toGray(img), w, h, 1);
    const at = (x, y) => {
      if (x < 0 || y < 0 || x > w - 2 || y > h - 2) return -1;
      const x0 = x | 0, y0 = y | 0, fx = x - x0, fy = y - y0, i = y0 * w + x0;
      const t = g[i] + (g[i + 1] - g[i]) * fx, b = g[i + w] + (g[i + w + 1] - g[i + w]) * fx;
      return t + (b - t) * fy;
    };
    const R = Math.max(8, Math.min(w, h) * 0.04);
    const c = quad.reduce((a, p) => [a[0] + p[0] / 4, a[1] + p[1] / 4], [0, 0]);
    const lines = [];
    for (let k = 0; k < 4; k++) {
      const a = quad[k], b = quad[(k + 1) % 4];
      const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
      if (len < 10) return quad;
      let nx = -dy / len, ny = dx / len;
      const mx = (a[0] + b[0]) / 2, my = (a[1] + b[1]) / 2;
      if ((c[0] - mx) * nx + (c[1] - my) * ny < 0) { nx = -nx; ny = -ny; } // normal points inside
      const pts = [];
      const N = 24;
      for (let j = 0; j < N; j++) {
        const t = 0.1 + 0.8 * j / (N - 1);
        const px = a[0] + dx * t, py = a[1] + dy * t;
        // gradient profile across the side; prefer the OUTERMOST strong edge so that
        // text, lines or pictures printed near the border don't pull the side inwards
        const prof = [];
        let best = 0, bestO = null;
        for (let o = -R; o <= R; o += 0.5) {
          const v1 = at(px + nx * (o - 1.5), py + ny * (o - 1.5)), v2 = at(px + nx * (o + 1.5), py + ny * (o + 1.5));
          if (v1 < 0 || v2 < 0) continue;
          const gr = Math.abs(v2 - v1);
          prof.push([o, gr]);
          if (gr > best) best = gr;
        }
        for (let q = 1; q < prof.length - 1; q++) {
          const [o, gr] = prof[q];
          if (gr >= best * 0.3 && gr >= 15 && gr >= prof[q - 1][1] && gr >= prof[q + 1][1]) { bestO = o; break; }
        }
        if (bestO !== null && best > 12) pts.push([px + nx * bestO, py + ny * bestO, bestO]);
      }
      if (pts.length < 8) { lines.push(null); continue; }
      // keep the points that agree with the median offset
      const offs = pts.map((p) => p[2]).sort((u, v) => u - v), med = offs[offs.length >> 1];
      const good = pts.filter((p) => Math.abs(p[2] - med) < R * 0.35);
      if (good.length < 6) { lines.push(null); continue; }
      // total least squares line fit
      let sx = 0, sy = 0;
      for (const p of good) { sx += p[0]; sy += p[1]; }
      sx /= good.length; sy /= good.length;
      let xx = 0, xy = 0, yy = 0;
      for (const p of good) { const ux = p[0] - sx, uy = p[1] - sy; xx += ux * ux; xy += ux * uy; yy += uy * uy; }
      const ang = 0.5 * Math.atan2(2 * xy, xx - yy);
      lines.push({ p: [sx, sy], d: [Math.cos(ang), Math.sin(ang)] });
    }
    const orig = (k) => { // fallback line through the original side
      const a = quad[k], b = quad[(k + 1) % 4], L = Math.hypot(b[0] - a[0], b[1] - a[1]);
      return { p: a, d: [(b[0] - a[0]) / L, (b[1] - a[1]) / L] };
    };
    const Ls = lines.map((l, k) => l || orig(k));
    const out = [];
    for (let k = 0; k < 4; k++) {
      const l1 = Ls[(k + 3) % 4], l2 = Ls[k]; // corner k is shared by side k-1 and side k
      const det = l1.d[0] * l2.d[1] - l1.d[1] * l2.d[0];
      if (Math.abs(det) < 1e-6) return quad;
      const t = ((l2.p[0] - l1.p[0]) * l2.d[1] - (l2.p[1] - l1.p[1]) * l2.d[0]) / det;
      const p = [l1.p[0] + l1.d[0] * t, l1.p[1] + l1.d[1] * t];
      if (Math.hypot(p[0] - quad[k][0], p[1] - quad[k][1]) > R * 1.6) return quad;
      out.push([Math.min(w, Math.max(0, p[0])), Math.min(h, Math.max(0, p[1]))]);
    }
    // nudge slightly inside so no background shows at the borders
    const cc = out.reduce((a, p) => [a[0] + p[0] / 4, a[1] + p[1] / 4], [0, 0]);
    return out.map((p) => [p[0] + (cc[0] - p[0]) * 0.004, p[1] + (cc[1] - p[1]) * 0.004]);
  }

  /* ---------------- perspective ---------------- */

  function solve(A, b) {
    const n = b.length;
    for (let i = 0; i < n; i++) {
      let p = i;
      for (let r = i + 1; r < n; r++) if (Math.abs(A[r][i]) > Math.abs(A[p][i])) p = r;
      [A[i], A[p]] = [A[p], A[i]]; [b[i], b[p]] = [b[p], b[i]];
      for (let r = i + 1; r < n; r++) {
        const f = A[r][i] / A[i][i];
        for (let c = i; c < n; c++) A[r][c] -= f * A[i][c];
        b[r] -= f * b[i];
      }
    }
    const x = new Array(n).fill(0);
    for (let i = n - 1; i >= 0; i--) {
      let s = b[i];
      for (let c = i + 1; c < n; c++) s -= A[i][c] * x[c];
      x[i] = s / A[i][i];
    }
    return x;
  }

  /* homography mapping points src[i] -> dst[i] */
  function homography(src, dst) {
    const A = [], b = [];
    for (let i = 0; i < 4; i++) {
      const [x, y] = src[i], [u, v] = dst[i];
      A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
      A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
    }
    const h = solve(A, b);
    return [h[0], h[1], h[2], h[3], h[4], h[5], h[6], h[7], 1];
  }

  const dist2 = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);

  function outputSize(quad, maxSide) {
    const [tl, tr, br, bl] = quad;
    let W = Math.max(dist2(tl, tr), dist2(bl, br));
    let H = Math.max(dist2(tl, bl), dist2(tr, br));
    const s = Math.min(1, maxSide / Math.max(W, H));
    return [Math.max(1, Math.round(W * s)), Math.max(1, Math.round(H * s))];
  }

  /* warp the quad region of src into a W×H rectangle (bilinear) */
  function warp(src, quad, maxSide) {
    const [W, H] = outputSize(quad, maxSide || 2400);
    const Hm = homography([[0, 0], [W, 0], [W, H], [0, H]], quad);
    const out = new Uint8ClampedArray(W * H * 4);
    const sd = src.data, sw = src.width, sh = src.height;
    for (let y = 0; y < H; y++) {
      const v = y + 0.5;
      for (let x = 0; x < W; x++) {
        const u = x + 0.5;
        const z = Hm[6] * u + Hm[7] * v + 1;
        let sx = (Hm[0] * u + Hm[1] * v + Hm[2]) / z - 0.5;
        let sy = (Hm[3] * u + Hm[4] * v + Hm[5]) / z - 0.5;
        if (sx < 0) sx = 0; else if (sx > sw - 1.001) sx = sw - 1.001;
        if (sy < 0) sy = 0; else if (sy > sh - 1.001) sy = sh - 1.001;
        const x0 = sx | 0, y0 = sy | 0, fx = sx - x0, fy = sy - y0;
        const p00 = (y0 * sw + x0) * 4, p10 = p00 + 4, p01 = p00 + sw * 4, p11 = p01 + 4;
        const o = (y * W + x) * 4;
        for (let c = 0; c < 3; c++) {
          const top = sd[p00 + c] + (sd[p10 + c] - sd[p00 + c]) * fx;
          const bot = sd[p01 + c] + (sd[p11 + c] - sd[p01 + c]) * fx;
          out[o + c] = top + (bot - top) * fy;
        }
        out[o + 3] = 255;
      }
    }
    return { data: out, width: W, height: H };
  }

  /* ---------------- filters ---------------- */

  /* block-level bright value (≈ paper level) of one channel */
  function blockLevels(chan, w, h, bs) {
    const bw = Math.ceil(w / bs), bh = Math.ceil(h / bs);
    const map = new Float32Array(bw * bh);
    const tmp = [];
    const step = Math.max(1, bs >> 3);
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      tmp.length = 0;
      const y1 = Math.min(h, (by + 1) * bs), x1 = Math.min(w, (bx + 1) * bs);
      for (let y = by * bs; y < y1; y += step) for (let x = bx * bs; x < x1; x += step) tmp.push(chan[y * w + x]);
      tmp.sort((a, b) => a - b);
      map[by * bw + bx] = tmp[Math.floor(tmp.length * 0.9)] || 255;
    }
    return { map, bw, bh, bs };
  }

  /* which blocks show bare paper: not much darker than the brightest paper nearby */
  function paperBlocks(lum) {
    const { map, bw, bh } = lum;
    const R = Math.max(3, Math.round(Math.max(bw, bh) / 5));
    const valid = new Uint8Array(bw * bh);
    for (let y = 0; y < bh; y++) for (let x = 0; x < bw; x++) {
      let m = 0;
      for (let yy = Math.max(0, y - R); yy <= Math.min(bh - 1, y + R); yy++)
        for (let xx = Math.max(0, x - R); xx <= Math.min(bw - 1, x + R); xx++) m = Math.max(m, map[yy * bw + xx]);
      valid[y * bw + x] = map[y * bw + x] >= 0.72 * m ? 1 : 0;
    }
    return valid;
  }

  /* fill non-paper blocks from paper neighbours, then smooth */
  function smoothBackground(level, valid) {
    const { bw, bh } = level;
    const map = Float32Array.from(level.map);
    let ok = Uint8Array.from(valid);
    if (!ok.some((v) => v)) ok.fill(1);
    for (let iter = 0; iter < bw + bh; iter++) {
      let missing = 0;
      const next = Uint8Array.from(ok);
      for (let y = 0; y < bh; y++) for (let x = 0; x < bw; x++) {
        const i = y * bw + x;
        if (ok[i]) continue;
        let s = 0, c = 0;
        for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
          const yy = y + dy, xx = x + dx;
          if (yy >= 0 && xx >= 0 && yy < bh && xx < bw && ok[yy * bw + xx]) { s += map[yy * bw + xx]; c++; }
        }
        if (c) { map[i] = s / c; next[i] = 1; } else missing++;
      }
      ok = next;
      if (!missing) break;
    }
    const sm = boxBlur(boxBlur(map, bw, bh, 1), bw, bh, 1);
    return { map: sm, bw, bh, bs: level.bs };
  }

  function sampleBg(bg, x, y) {
    const fx = Math.min(bg.bw - 1, Math.max(0, (x + 0.5) / bg.bs - 0.5));
    const fy = Math.min(bg.bh - 1, Math.max(0, (y + 0.5) / bg.bs - 0.5));
    const x0 = fx | 0, y0 = fy | 0, x1 = Math.min(bg.bw - 1, x0 + 1), y1 = Math.min(bg.bh - 1, y0 + 1);
    const ax = fx - x0, ay = fy - y0, m = bg.map, w = bg.bw;
    const t = m[y0 * w + x0] + (m[y0 * w + x1] - m[y0 * w + x0]) * ax;
    const b = m[y1 * w + x0] + (m[y1 * w + x1] - m[y1 * w + x0]) * ax;
    return Math.max(30, t + (b - t) * ay);
  }

  /* per-pixel paper level for each channel in chans (lum decides which blocks are paper) */
  function backgrounds(chans, lumChan, w, h) {
    const bs = Math.max(8, Math.round(Math.max(w, h) / 40));
    const valid = paperBlocks(blockLevels(lumChan, w, h, bs));
    return chans.map((c) => {
      const bg = smoothBackground(blockLevels(c, w, h, bs), valid);
      const out = new Float32Array(w * h);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) out[y * w + x] = sampleBg(bg, x, y);
      return out;
    });
  }

  const FILTERS = ['enhanced', 'original', 'gray', 'bw', 'inksave'];
  const FILTER_NAMES = {
    original: 'الأصلية', enhanced: 'ألوان محسّنة', gray: 'رمادي', bw: 'أبيض وأسود', inksave: 'توفير الحبر'
  };

  /* apply filter + brightness (-100..100) + contrast (-100..100) */
  function applyFilter(img, filter, brightness, contrast) {
    const { width: w, height: h, data } = img;
    const out = new Uint8ClampedArray(data.length);
    const n = w * h;
    brightness = brightness || 0; contrast = contrast || 0;

    if (filter === 'original') {
      out.set(data);
    } else if (filter === 'enhanced') {
      const ch = [new Float32Array(n), new Float32Array(n), new Float32Array(n)];
      for (let i = 0, p = 0; i < n; i++, p += 4) { ch[0][i] = data[p]; ch[1][i] = data[p + 1]; ch[2][i] = data[p + 2]; }
      const bgs = backgrounds(ch, toGray(img), w, h);
      for (let i = 0, p = 0; i < n; i++, p += 4) {
        let r = ch[0][i] / bgs[0][i], g = ch[1][i] / bgs[1][i], b = ch[2][i] / bgs[2][i];
        // levels: paper -> white, push darks a bit
        const lv = (v) => { v = (v - 0.12) / 0.83; return v <= 0 ? 0 : v >= 1 ? 1 : Math.pow(v, 1.35); };
        r = lv(r); g = lv(g); b = lv(b);
        // saturation boost
        const l = 0.299 * r + 0.587 * g + 0.114 * b, s = 1.15;
        out[p] = (l + (r - l) * s) * 255; out[p + 1] = (l + (g - l) * s) * 255; out[p + 2] = (l + (b - l) * s) * 255;
        out[p + 3] = 255;
      }
    } else {
      const g = toGray(img);
      const bg = backgrounds([g], g, w, h)[0];
      for (let i = 0, p = 0; i < n; i++, p += 4) {
        const v = g[i] / bg[i];
        let o;
        if (filter === 'gray') {
          let t = (v - 0.15) / 0.8; t = t <= 0 ? 0 : t >= 1 ? 1 : Math.pow(t, 1.4); o = t * 255;
        } else if (filter === 'bw') {
          const th = 0.8 - brightness / 400;
          const t = (v - (th - 0.06)) / 0.12; o = t <= 0 ? 0 : t >= 1 ? 255 : t * 255;
        } else { // inksave
          if (v > 0.86) o = 255; else { const t = Math.max(0, (v - 0.4) / 0.46); o = 95 + t * 160; }
        }
        out[p] = out[p + 1] = out[p + 2] = o; out[p + 3] = 255;
      }
    }

    if ((brightness && filter !== 'bw') || contrast) {
      const c = Math.pow((contrast + 100) / 100, 1.6), b = filter === 'bw' ? 0 : brightness * 1.1;
      for (let p = 0; p < out.length; p += 4) {
        out[p] = (out[p] - 128) * c + 128 + b;
        out[p + 1] = (out[p + 1] - 128) * c + 128 + b;
        out[p + 2] = (out[p + 2] - 128) * c + 128 + b;
      }
    }
    return { data: out, width: w, height: h };
  }

  /* suggest a filter: text-only pages -> bw, pages with colour -> enhanced */
  function suggest(img) {
    const { data, width: w, height: h } = img;
    let colored = 0, total = 0, dark = 0;
    const step = Math.max(1, Math.floor(Math.sqrt((w * h) / 40000)));
    for (let y = Math.floor(h * 0.05); y < h * 0.95; y += step) for (let x = Math.floor(w * 0.05); x < w * 0.95; x += step) {
      const p = (y * w + x) * 4, r = data[p], g = data[p + 1], b = data[p + 2];
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
      total++;
      if (mx - mn > 45 && mx > 60) colored++;
      if (mx < 90) dark++;
    }
    const cf = colored / total, df = dark / total;
    if (cf > 0.04) return 'enhanced';
    if (df > 0.35) return 'gray'; // big dark areas (photos) look bad in pure b/w
    return 'bw';
  }

  function rotate90(img, times) {
    times = ((times % 4) + 4) % 4;
    let cur = img;
    for (let k = 0; k < times; k++) {
      const { width: w, height: h, data } = cur;
      const out = new Uint8ClampedArray(data.length);
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        const s = (y * w + x) * 4, nx = h - 1 - y, ny = x, d = (ny * h + nx) * 4;
        out[d] = data[s]; out[d + 1] = data[s + 1]; out[d + 2] = data[s + 2]; out[d + 3] = 255;
      }
      cur = { data: out, width: h, height: w };
    }
    return cur;
  }

  /* ---------------- PDF ---------------- */

  /* pages: [{jpeg:Uint8Array, width, height}] ; size: 'auto' | 'a4' */
  function makePdf(pages, size, title) {
    const enc = new TextEncoder();
    const chunks = [];
    let length = 0;
    const offsets = [];
    const push = (x) => { const b = typeof x === 'string' ? enc.encode(x) : x; chunks.push(b); length += b.length; };
    const obj = (id) => { offsets[id] = length; };

    push('%PDF-1.4\n');
    const n = pages.length;
    // ids: 1 catalog, 2 pages, 3 info, then per page: page, content, image
    const pid = (i) => 4 + i * 3;
    obj(1); push('1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n');
    obj(2); push('2 0 obj\n<< /Type /Pages /Count ' + n + ' /Kids [' + pages.map((_, i) => pid(i) + ' 0 R').join(' ') + '] >>\nendobj\n');
    const hex = (s) => { let o = 'FEFF'; for (const ch of s) { const c = ch.codePointAt(0); if (c > 0xffff) continue; o += c.toString(16).padStart(4, '0').toUpperCase(); } return '<' + o + '>'; };
    obj(3); push('3 0 obj\n<< /Producer (NEXA Scan) /Title ' + hex(title || 'NEXA Scan') + ' >>\nendobj\n');

    pages.forEach((pg, i) => {
      let pw, ph, dw, dh, dx, dy;
      if (size === 'a4') {
        const landscape = pg.width > pg.height;
        pw = landscape ? 842 : 595; ph = landscape ? 595 : 842;
        const m = 18, s = Math.min((pw - 2 * m) / pg.width, (ph - 2 * m) / pg.height);
        dw = pg.width * s; dh = pg.height * s; dx = (pw - dw) / 2; dy = (ph - dh) / 2;
      } else {
        const s = 595 / Math.min(pg.width, pg.height);
        pw = pg.width * s; ph = pg.height * s; dw = pw; dh = ph; dx = 0; dy = 0;
      }
      const f = (v) => (Math.round(v * 100) / 100).toString();
      const id = pid(i);
      obj(id); push(id + ' 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + f(pw) + ' ' + f(ph) + '] /Resources << /XObject << /Im0 ' + (id + 2) + ' 0 R >> >> /Contents ' + (id + 1) + ' 0 R >>\nendobj\n');
      const content = 'q ' + f(dw) + ' 0 0 ' + f(dh) + ' ' + f(dx) + ' ' + f(dy) + ' cm /Im0 Do Q';
      obj(id + 1); push((id + 1) + ' 0 obj\n<< /Length ' + content.length + ' >>\nstream\n' + content + '\nendstream\nendobj\n');
      obj(id + 2); push((id + 2) + ' 0 obj\n<< /Type /XObject /Subtype /Image /Width ' + pg.width + ' /Height ' + pg.height + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + pg.jpeg.length + ' >>\nstream\n');
      push(pg.jpeg);
      push('\nendstream\nendobj\n');
    });

    const total = 4 + n * 3;
    const xref = length;
    let x = 'xref\n0 ' + total + '\n0000000000 65535 f \n';
    for (let i = 1; i < total; i++) x += String(offsets[i]).padStart(10, '0') + ' 00000 n \n';
    push(x + 'trailer\n<< /Size ' + total + ' /Root 1 0 R /Info 3 0 R >>\nstartxref\n' + xref + '\n%%EOF\n');

    const out = new Uint8Array(length);
    let o = 0;
    for (const c of chunks) { out.set(c, o); o += c.length; }
    return out;
  }

  root.Scan = { detect, refine, warp, applyFilter, suggest, rotate90, makePdf, outputSize, FILTERS, FILTER_NAMES };
})(typeof window !== 'undefined' ? window : globalThis);
