/* NEXA Scan — app logic */
(function () {
  'use strict';
  const VERSION = '2.1.2';
  const $ = (id) => document.getElementById(id);
  const isAndroidApp = typeof window.Android !== 'undefined';
  const isIOS = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const SRC_CAP = 3000, OUT_CAP = 2400;

  /* ================= storage (IndexedDB) ================= */
  const DB = {
    db: null,
    open() {
      return new Promise((res, rej) => {
        const r = indexedDB.open('nexa-scan', 1);
        r.onupgradeneeded = () => {
          const d = r.result;
          d.createObjectStore('docs', { keyPath: 'id' });
          d.createObjectStore('pages', { keyPath: 'id' });
        };
        r.onsuccess = () => { DB.db = r.result; res(); };
        r.onerror = () => rej(r.error);
      });
    },
    tx(store, mode, fn) {
      return new Promise((res, rej) => {
        const t = DB.db.transaction(store, mode), s = t.objectStore(store);
        const r = fn(s);
        t.oncomplete = () => res(r && r.result);
        t.onerror = () => rej(t.error);
        t.onabort = () => rej(t.error);
      });
    },
    get: (s, k) => DB.tx(s, 'readonly', (st) => st.get(k)),
    put: (s, v) => DB.tx(s, 'readwrite', (st) => st.put(v)),
    del: (s, k) => DB.tx(s, 'readwrite', (st) => st.delete(k)),
    all: (s) => DB.tx(s, 'readonly', (st) => st.getAll())
  };
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  /* ================= ui helpers ================= */
  function show(id) {
    document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('on', s.id === id));
    current = id;
    applyBars();
  }
  let current = 'home';
  function applyBars() {
    if (isAndroidApp && Android.setDark) { try { Android.setDark(current === 'crop' || current === 'edit'); } catch (e) { } }
  }
  let toastT = 0;
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.classList.add('on');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600);
  }
  window.nexaToast = (m) => toast(m);
  function busy(on, text) { $('busy').classList.toggle('on', !!on); if (text) $('busyText').textContent = text; }
  const frame = () => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 0)));
  let openSheetEl = null;
  function openSheet(id) { closeSheet(); openSheetEl = $(id); $('veil').classList.add('on'); openSheetEl.classList.add('on'); }
  function closeSheet() { if (openSheetEl) openSheetEl.classList.remove('on'); openSheetEl = null; if (!dlgOpen) $('veil').classList.remove('on'); }
  $('veil').onclick = () => { if (dlgOpen) dlgClose(false); else closeSheet(); };

  let dlgOpen = null;
  function dialog({ title, text, input, yes, danger }) {
    return new Promise((res) => {
      closeSheet();
      $('dlgTitle').textContent = title; $('dlgText').textContent = text || '';
      $('dlgText').classList.toggle('hidden', !text);
      const inp = $('dlgInput');
      inp.classList.toggle('hidden', input === undefined);
      if (input !== undefined) inp.value = input;
      $('dlgYes').textContent = yes || t('موافق');
      $('dlgYes').className = 'btn ' + (danger ? 'danger' : 'primary');
      $('dlg').classList.add('on'); $('veil').classList.add('on');
      dlgOpen = res;
      if (input !== undefined) setTimeout(() => { inp.focus(); inp.select(); }, 50);
    });
  }
  function dlgClose(ok) {
    const res = dlgOpen; dlgOpen = null;
    $('dlg').classList.remove('on'); $('veil').classList.remove('on');
    if (res) res(ok ? ($('dlgInput').classList.contains('hidden') ? true : $('dlgInput').value.trim()) : false);
  }
  $('dlgYes').onclick = () => dlgClose(true);
  $('dlgNo').onclick = () => dlgClose(false);

  const dateFmt = new Intl.DateTimeFormat(LANG === 'ar' ? 'ar-u-nu-latn' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' });
  const timeFmt = new Intl.DateTimeFormat(LANG === 'ar' ? 'ar-u-nu-latn' : 'en-US', { hour: 'numeric', minute: '2-digit' });
  function defaultName() {
    const d = new Date();
    return t('مستند ') + dateFmt.format(d) + t('، ') + timeFmt.format(d);
  }
  const pagesWord = (n) => n === 1 ? t('صفحة واحدة') : n === 2 ? t('صفحتان') : n <= 10 ? n + t(' صفحات') : n + t(' صفحة');

  /* ================= Pro ================= */
  const PLAY = isAndroidApp && typeof Android.isPro === 'function';
  const FREE_PAGES = 5;
  let pro = PLAY ? !!Android.isPro() : true; // web/iPhone version is not sold: everything open
  let plans = null, planSel = 'yearly', proAfter = null;
  function applyPro() {
    document.body.classList.toggle('is-pro', pro);
    $('proTag').classList.toggle('hidden', !pro || !PLAY);
    $('proBtn').classList.toggle('hidden', !PLAY);
    $('planBox').classList.toggle('hidden', pro);
    $('proActive').classList.toggle('hidden', !pro);
    $('restoreBtn').classList.toggle('hidden', pro);
    $('codeBtn').classList.toggle('hidden', pro);
  }
  window.nexaPro = (v) => {
    const was = pro; pro = !!v; applyPro();
    if (pro && !was && current === 'pro') { closePro(); if (proAfter) { const f = proAfter; proAfter = null; f(); } }
    if (current === 'doc' && doc) openDoc(doc.id);
  };
  window.nexaPlans = (j) => { try { plans = JSON.parse(j); } catch (e) { plans = null; } renderPlans(); };
  function renderPlans() {
    const m = plans && plans.monthly, y = plans && plans.yearly;
    $('pMonth').textContent = m ? m.price : '—';
    $('pYear').textContent = y ? y.price : '—';
    $('pYearM').textContent = y ? t('يُدفع سنوياً') : '';
    if (m && y && m.micros) {
      const save = Math.round((1 - y.micros / (m.micros * 12)) * 100);
      $('saveTag').textContent = save > 0 ? t('وفّر ') + save + '%' : '';
    }
    document.querySelectorAll('.plan').forEach((b) => b.classList.toggle('on', b.dataset.plan === planSel));
    const sel = plans && plans[planSel];
    $('buyBtn').disabled = !sel;
    if (!sel) { $('buyBtn').textContent = plans ? t('غير متاح حالياً') : t('جارٍ تحميل الأسعار…'); $('buyFine').textContent = ''; return; }
    const per = planSel === 'yearly' ? t('سنوياً') : t('شهرياً');
    if (sel.trial) {
      $('buyBtn').textContent = t('ابدأ التجربة المجانية 3 أيام');
      $('buyFine').textContent = t('مجاناً لمدة 3 أيام، ثم ') + sel.price + ' ' + per + t('. يتجدد الاشتراك تلقائياً ويمكنك إلغاؤه في أي وقت من Google Play قبل انتهاء التجربة دون أي رسوم.');
    } else {
      $('buyBtn').textContent = t('اشترك بـ ') + sel.price + ' ' + per;
      $('buyFine').textContent = t('يتجدد الاشتراك تلقائياً ويمكنك إلغاؤه في أي وقت من Google Play.');
    }
  }
  const REASONS = {
    pages: t('النسخة المجانية تتيح ') + FREE_PAGES + t(' صفحات في المستند الواحد'),
    target: t('الضغط لحجم محدد من مزايا Pro'),
    lock: t('قفل ملفات PDF بكلمة سر من مزايا Pro'),
    id: t('وضع الهوية من مزايا Pro'),
    burst: t('المسح المتتالي من مزايا Pro')
  };
  let proFrom = 'home';
  function openPro(reason, after) {
    if (!PLAY) return;
    proFrom = current; proAfter = after || null;
    $('proReason').textContent = REASONS[reason] || t('كل أدوات المسح الاحترافية بلا حدود');
    closeSheet();
    if (!plans) { try { const j = Android.plans(); if (j) plans = JSON.parse(j); } catch (e) { } }
    renderPlans(); applyPro();
    show('pro');
    try { Android.restore(); } catch (e) { }
  }
  function closePro() { show(proFrom === 'pro' ? 'home' : proFrom); if (current === 'home') renderHome(); }
  /* runs fn if Pro, otherwise shows the subscription screen */
  function needPro(reason, fn) { if (pro) return fn(); openPro(reason, fn); }
  $('proBtn').onclick = () => openPro();
  /* settings: language & theme */
  function segPick(id, val, fn) {
    document.querySelectorAll('#' + id + ' button').forEach((b) => {
      b.classList.toggle('on', b.dataset.v === val);
      b.onclick = () => { document.querySelectorAll('#' + id + ' button').forEach((x) => x.classList.toggle('on', x === b)); fn(b.dataset.v); };
    });
  }
  $('setBtn').onclick = () => {
    segPick('segLang', LANG, (v) => { if (v !== LANG) { closeSheet(); window.nexaSetLang(v); } });
    segPick('segTheme', nexaTheme.get(), (v) => { nexaTheme.set(v); applyBars(); });
    openSheet('setSheet');
  };
  $('proClose').onclick = closePro;
  document.querySelectorAll('.plan').forEach((b) => { b.onclick = () => { planSel = b.dataset.plan; renderPlans(); }; });
  $('buyBtn').onclick = () => { if (PLAY) Android.buy(planSel); };
  $('restoreBtn').onclick = () => { if (PLAY) { Android.restore(); toast(t('جارٍ التحقق من اشتراكك…')); setTimeout(() => { if (!pro) toast(t('لا يوجد اشتراك فعّال على حساب Google هذا')); }, 3500); } };
  $('codeBtn').onclick = async () => {
    if (!PLAY || !Android.redeem) return;
    const c = await dialog({ title: t('رمز التفعيل'), input: '', yes: t('تفعيل') });
    if (!c) return;
    if (Android.redeem(c)) { toast(t('تم تفعيل Pro')); } else toast(t('الرمز غير صحيح'));
  };
  $('manageBtn').onclick = () => { if (PLAY) Android.manageSubscription(); };

  /* full-screen ad every 3rd export in the free version */
  function maybeInterstitial() {
    if (!PLAY || pro) return;
    let n = 0;
    try { n = (+localStorage.getItem('exportCount') || 0) + 1; localStorage.setItem('exportCount', n); } catch (e) { n = 3; }
    if (n % 3 === 0) { try { Android.showInterstitial(); } catch (e) { } }
  }

  function footer() {
    return t('تم التطوير من <a href="https://instagram.com/nexa.ryx" target="_blank" rel="noopener">NEXA</a> للخدمات الرقمية<br>') +
      '© NEXA ' + new Date().getFullYear() + t(' · جميع الحقوق محفوظة<br>الإصدار ') + VERSION +
      (isAndroidApp && Android.privacyNeeded && Android.privacyNeeded() ? t('<br><button class="privacy-link" onclick="Android.privacyOptions()">خيارات الخصوصية والإعلانات</button>') : '');
  }
  $('footer1').innerHTML = footer();
  $('footer2').innerHTML = footer();

  /* ================= image helpers ================= */
  function canvasOf(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  function loadImg(src) {
    return new Promise((res, rej) => {
      const url = typeof src === 'string' ? src : URL.createObjectURL(src);
      const i = new Image();
      i.onload = () => { if (typeof src !== 'string') URL.revokeObjectURL(url); res(i); };
      i.onerror = () => { if (typeof src !== 'string') URL.revokeObjectURL(url); rej(new Error('img')); };
      i.src = url;
    });
  }
  async function blobToCanvas(blob, cap) {
    const img = await loadImg(blob);
    const s = Math.min(1, cap / Math.max(img.naturalWidth, img.naturalHeight));
    const c = canvasOf(Math.round(img.naturalWidth * s), Math.round(img.naturalHeight * s));
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    return c;
  }
  function scaled(canvasOrImg, cap) {
    const w = canvasOrImg.width, h = canvasOrImg.height, s = Math.min(1, cap / Math.max(w, h));
    const c = canvasOf(Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s)));
    const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(canvasOrImg, 0, 0, c.width, c.height);
    return c;
  }
  const imgData = (c) => c.getContext('2d').getImageData(0, 0, c.width, c.height);
  function dataToCanvas(d) {
    const c = canvasOf(d.width, d.height);
    c.getContext('2d').putImageData(new ImageData(d.data, d.width, d.height), 0, 0);
    return c;
  }
  const toBlob = (c, q) => new Promise((r) => c.toBlob(r, 'image/jpeg', q));
  function detectQuad(src) {
    const small = scaled(src, 400), s = small.width / src.width;
    const r = Scan.detect(imgData(small));
    let quad = r.quad.map((p) => [p[0] / s, p[1] / s]);
    if (r.found) {
      try {
        const mid = scaled(src, 1000), m = mid.width / src.width;
        quad = Scan.refine(imgData(mid), quad.map((p) => [p[0] * m, p[1] * m])).map((p) => [p[0] / m, p[1] / m]);
      } catch (e) { /* keep rough quad */ }
    }
    return { found: r.found, quad };
  }
  const fullQuad = (c) => [[0, 0], [c.width, 0], [c.width, c.height], [0, c.height]];

  /* ================= state ================= */
  let doc = null;           // open document
  let draft = null;         // page being made/edited
  let pickFor = 'new';      // where picked images go

  /* ================= home ================= */
  const urls = [];
  function freeUrls() { while (urls.length) URL.revokeObjectURL(urls.pop()); }
  const urlOf = (blob) => { const u = URL.createObjectURL(blob); urls.push(u); return u; };

  async function renderHome() {
    freeUrls();
    const docs = (await DB.all('docs')).sort((a, b) => b.updated - a.updated);
    const q = $('q').value.trim();
    const list = q ? docs.filter((d) => d.name.includes(q)) : docs;
    const box = $('docList');
    box.innerHTML = '';
    $('empty').classList.toggle('hidden', docs.length > 0);
    if (q && !list.length) box.innerHTML = t('<div class="empty" style="padding-top:20px">لا توجد نتائج لـ «') + q.replace(/[<>&]/g, '') + '»</div>';
    for (const d of list) {
      const first = d.pages.length ? await DB.get('pages', d.pages[0]) : null;
      const el = document.createElement('div');
      el.className = 'doc';
      const dt = new Date(d.updated);
      el.innerHTML = '<img alt=""><div class="meta"><b></b><span></span></div><button class="more"><svg class="i"><use href="#i-more"/></svg></button>';
      if (first && first.thumb) el.querySelector('img').src = urlOf(first.thumb);
      el.querySelector('b').textContent = d.name;
      el.querySelector('span').textContent = pagesWord(d.pages.length) + ' · ' + dateFmt.format(dt) + ' ' + timeFmt.format(dt);
      el.onclick = () => openDoc(d.id);
      el.querySelector('.more').onclick = (e) => { e.stopPropagation(); docMenu(d, false); };
      box.appendChild(el);
    }
  }
  $('q').oninput = () => renderHome();

  if (isIOS && !navigator.standalone && !isAndroidApp) {
    try { if (!localStorage.getItem('iosTipHidden')) $('iosTip').classList.remove('hidden'); } catch (e) { $('iosTip').classList.remove('hidden'); }
  }
  $('iosTipX').onclick = () => { $('iosTip').classList.add('hidden'); try { localStorage.setItem('iosTipHidden', '1'); } catch (e) { } };

  /* ================= picking images ================= */
  let mode = null;   // null | 'id' | 'burst'
  let idFront = null; // processed front side of an ID card
  const openCam = () => { $('fCam').value = ''; $('fCam').click(); };
  const roomLeft = () => pro ? Infinity : FREE_PAGES - (pickFor === 'add' && doc ? doc.pages.length : 0);
  document.querySelectorAll('[data-pick]').forEach((b) => {
    b.onclick = () => {
      if (b.closest('.sheet')) closeSheet(); else pickFor = 'new';
      mode = null; idFront = null;
      if (roomLeft() <= 0) { openPro('pages'); return; }
      if (b.dataset.pick === 'camera') openCam();
      else { $('fGal').value = ''; $('fGal').click(); }
    };
  });
  $('mId').onclick = () => needPro('id', () => {
    pickFor = 'new'; mode = 'id'; idFront = null;
    toast(t('صوّر الوجه الأمامي للبطاقة'));
    openCam();
  });
  $('mBurst').onclick = () => needPro('burst', () => {
    pickFor = 'new'; mode = 'burst'; doc = null;
    openCam();
  });
  $('fCam').onchange = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    if (mode === 'burst') burstAdd(f); else startDraft(f);
  };
  $('fGal').onchange = (e) => {
    let files = Array.from(e.target.files || []);
    const room = roomLeft();
    if (files.length > room) { files = files.slice(0, room); setTimeout(() => toast(t('أُضيفت أول ') + room + t(' صور فقط، اشترك في Pro لصفحات بلا حدود')), 400); }
    if (files.length === 1) startDraft(files[0]);
    else if (files.length > 1) batchImport(files);
  };

  /* continuous scan: auto crop + suggested filter, then straight to the next shot */
  async function burstAdd(file) {
    busy(true, t('جارٍ معالجة الصفحة…'));
    await frame();
    try {
      if (!doc || pickFor === 'new') { pickFor = 'new'; await ensureDoc(); pickFor = 'add'; }
      const src = await blobToCanvas(file, SRC_CAP);
      const d = detectQuad(src);
      const warped = Scan.warp(imgData(src), d.quad, OUT_CAP);
      await savePage({ pageId: null, src, quad: d.quad, filter: Scan.suggest(warped), bright: 0, contrast: 0, rot: 0, warped });
      const last = await DB.get('pages', doc.pages[doc.pages.length - 1]);
      freeUrls();
      $('burstImg').src = urlOf(last.thumb);
      $('burstCount').textContent = pagesWord(doc.pages.length);
      busy(false);
      show('burst');
    } catch (e) { busy(false); toast(t('تعذّر معالجة الصورة')); }
  }
  $('burstNext').onclick = openCam;
  $('burstDone').onclick = () => { mode = null; if (doc) openDoc(doc.id); else { show('home'); renderHome(); } };

  /* ID mode: put front and back on one A4 page */
  async function composeId(front, back) {
    const W = 1654, H = 2339; // A4 at 200 dpi
    const c = canvasOf(W, H), x = c.getContext('2d');
    x.fillStyle = '#fff'; x.fillRect(0, 0, W, H);
    const boxW = Math.round(85.6 / 25.4 * 200) * 1.25, boxH = Math.round(54 / 25.4 * 200) * 1.25; // a bit larger than real size for clarity
    const place = (img, cy) => {
      const k = Math.min(boxW / img.width, boxH / img.height);
      const w = img.width * k, h = img.height * k;
      x.imageSmoothingQuality = 'high';
      x.drawImage(img, (W - w) / 2, cy - h / 2, w, h);
    };
    place(front, H * 0.27);
    place(back, H * 0.66);
    return c;
  }

  async function ensureDoc() {
    if (pickFor === 'new' || !doc) {
      doc = { id: uid(), name: defaultName(), created: Date.now(), updated: Date.now(), pages: [] };
      await DB.put('docs', doc);
    }
  }

  async function startDraft(file) {
    busy(true, t('جارٍ تجهيز الصورة…'));
    await frame();
    try {
      const src = await blobToCanvas(file, SRC_CAP);
      const d = detectQuad(src);
      draft = { pageId: null, src, quad: d.quad, found: d.found, filter: null, bright: 0, contrast: 0, rot: 0, fromEdit: false };
      busy(false);
      openCrop();
    } catch (e) {
      busy(false); toast(t('تعذّر فتح الصورة'));
    }
  }

  async function batchImport(files) {
    await ensureDoc();
    let done = 0;
    for (let i = 0; i < files.length; i++) {
      busy(true, t('جارٍ معالجة الصورة ') + (i + 1) + t(' من ') + files.length + '…');
      await frame();
      try {
        const src = await blobToCanvas(files[i], SRC_CAP);
        const d = detectQuad(src);
        const warped = Scan.warp(imgData(src), d.quad, OUT_CAP);
        const filter = Scan.suggest(warped);
        await savePage({ pageId: null, src, quad: d.quad, filter, bright: 0, contrast: 0, rot: 0, warped });
        done++;
      } catch (e) { /* skip unreadable */ }
    }
    busy(false);
    if (done < files.length) toast(t('تعذّر فتح ') + (files.length - done) + t(' من الصور'));
    openDoc(doc.id);
  }

  /* ================= crop screen ================= */
  const crop = { scale: 1, ox: 0, oy: 0, drag: -1 };
  function openCrop() {
    show('crop');
    $('cropHint').textContent = draft.found ? t('اسحب الدوائر لضبط الحواف بدقة') : t('لم نتمكن من تحديد الورقة تلقائياً، اسحب الدوائر إلى زوايا الورقة');
    requestAnimationFrame(layoutCrop);
  }
  function layoutCrop() {
    const st = $('cropStage'), W = st.clientWidth, H = st.clientHeight, pad = 26;
    const src = draft.src;
    const s = Math.min((W - pad * 2) / src.width, (H - pad * 2) / src.height);
    crop.scale = s; crop.ox = (W - src.width * s) / 2; crop.oy = (H - src.height * s) / 2;
    const c = $('cropCanvas'), dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = Math.round(src.width * s * dpr); c.height = Math.round(src.height * s * dpr);
    c.style.width = src.width * s + 'px'; c.style.height = src.height * s + 'px';
    c.style.left = crop.ox + 'px'; c.style.top = crop.oy + 'px';
    const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(src, 0, 0, c.width, c.height);
    st.querySelectorAll('.handle').forEach((h) => h.remove());
    for (let i = 0; i < 4; i++) {
      const h = document.createElement('div'); h.className = 'handle'; h.dataset.i = i;
      h.addEventListener('pointerdown', handleDown);
      st.appendChild(h);
    }
    drawCrop();
  }
  function drawCrop() {
    const st = $('cropStage'), W = st.clientWidth, H = st.clientHeight;
    const pts = draft.quad.map((p) => [crop.ox + p[0] * crop.scale, crop.oy + p[1] * crop.scale]);
    const poly = pts.map((p) => p.join(',')).join(' ');
    $('cropOv').innerHTML =
      '<path fill="rgba(5,10,20,.55)" fill-rule="evenodd" d="M0 0H' + W + 'V' + H + 'H0Z M' + pts.map((p) => p.join(' ')).join(' L') + 'Z"/>' +
      '<polygon points="' + poly + '" fill="none" stroke="#1FB6C9" stroke-width="2.5" stroke-linejoin="round"/>';
    st.querySelectorAll('.handle').forEach((h, i) => { h.style.left = pts[i][0] + 'px'; h.style.top = pts[i][1] + 'px'; });
  }
  function handleDown(e) {
    e.preventDefault();
    crop.drag = +e.currentTarget.dataset.i;
    const st = $('cropStage'), r = st.getBoundingClientRect();
    const p = draft.quad[crop.drag];
    crop.grab = [e.clientX - r.left - (crop.ox + p[0] * crop.scale), e.clientY - r.top - (crop.oy + p[1] * crop.scale)];
    e.currentTarget.setPointerCapture(e.pointerId);
    e.currentTarget.onpointermove = handleMove;
    e.currentTarget.onpointerup = e.currentTarget.onpointercancel = handleUp;
    handleMove(e);
  }
  function handleMove(e) {
    if (crop.drag < 0) return;
    const st = $('cropStage'), r = st.getBoundingClientRect();
    const sx = e.clientX - r.left - crop.grab[0], sy = e.clientY - r.top - crop.grab[1];
    const ix = Math.max(0, Math.min(draft.src.width, (sx - crop.ox) / crop.scale));
    const iy = Math.max(0, Math.min(draft.src.height, (sy - crop.oy) / crop.scale));
    draft.quad[crop.drag] = [ix, iy];
    drawCrop();
    // loupe
    const L = $('loupe'), lc = $('loupeCanvas'), x = lc.getContext('2d');
    const zoom = 2.6 * crop.scale, size = 110;
    x.fillStyle = '#000'; x.fillRect(0, 0, size, size);
    x.drawImage(draft.src, ix - size / 2 / zoom, iy - size / 2 / zoom, size / zoom, size / zoom, 0, 0, size, size);
    // draw neighbouring edges inside the loupe
    x.strokeStyle = '#1FB6C9'; x.lineWidth = 2; x.beginPath();
    const q = draft.quad, i = crop.drag, a = q[(i + 3) % 4], b = q[(i + 1) % 4];
    const m = (p) => [size / 2 + (p[0] - ix) * zoom, size / 2 + (p[1] - iy) * zoom];
    x.moveTo(...m(a)); x.lineTo(size / 2, size / 2); x.lineTo(...m(b)); x.stroke();
    L.style.display = 'block';
    const px = crop.ox + ix * crop.scale, py = crop.oy + iy * crop.scale;
    let ly = py - 150; if (ly < 4) ly = py + 50;
    let lx = px - 55; lx = Math.max(4, Math.min(st.clientWidth - 114, lx));
    L.style.left = lx + 'px'; L.style.top = ly + 'px';
  }
  function handleUp(e) {
    crop.drag = -1; $('loupe').style.display = 'none';
    e.currentTarget.onpointermove = null;
  }
  window.addEventListener('resize', () => { if (current === 'crop') layoutCrop(); else if (current === 'edit') renderEdit(); });

  $('tAuto').onclick = () => {
    const d = detectQuad(draft.src);
    draft.quad = d.quad; drawCrop();
    toast(d.found ? t('تم تحديد الورقة') : t('لم يتم العثور على حواف واضحة'));
  };
  $('tFull').onclick = () => { draft.quad = fullQuad(draft.src); drawCrop(); };
  $('cropRetake').onclick = () => {
    if (draft.fromEdit) { $('cropBack').onclick(); return; }
    $('fCam').value = ''; $('fCam').click();
  };
  $('cropBack').onclick = () => {
    if (draft && draft.fromEdit) { draft.quad = draft.quadBefore; draft.fromEdit = false; show('edit'); renderEdit(); return; }
    draft = null;
    if (mode === 'id') { mode = null; idFront = null; }
    if (doc && pickFor === 'add') openDoc(doc.id); else { show('home'); renderHome(); }
  };
  function quadOk(q) {
    let a = 0;
    for (let i = 0; i < 4; i++) { const p = q[i], n = q[(i + 1) % 4]; a += p[0] * n[1] - n[0] * p[1]; }
    return Math.abs(a / 2) > draft.src.width * draft.src.height * 0.01;
  }
  $('cropNext').onclick = async () => {
    if (!quadOk(draft.quad)) { toast(t('المنطقة المحددة صغيرة جداً')); return; }
    busy(true, t('جارٍ تصحيح الميلان…'));
    await frame();
    draft.warped = Scan.warp(imgData(draft.src), draft.quad, OUT_CAP);
    draft.suggested = Scan.suggest(draft.warped);
    if (!draft.filter) draft.filter = draft.suggested;
    draft.fromEdit = false;
    prepEdit();
    busy(false);
    show('edit');
    renderEdit(true);
  };

  /* ================= edit screen ================= */
  let prev = null, thumbBase = null;
  function prepEdit() {
    const wc = dataToCanvas(draft.warped);
    prev = imgData(scaled(wc, 1100));
    thumbBase = imgData(scaled(wc, 170));
    wc.width = 0;
    $('sBright').value = draft.bright; $('sContrast').value = draft.contrast;
    $('vBright').textContent = draft.bright; $('vContrast').textContent = draft.contrast;
  }
  function renderThumbs() {
    const box = $('filters'); box.innerHTML = '';
    for (const f of Scan.FILTERS) {
      const el = document.createElement('button');
      el.className = 'f' + (f === draft.filter ? ' on' : '');
      const out = Scan.applyFilter(thumbBase, f, 0, 0);
      const c = dataToCanvas(out);
      el.appendChild(c);
      el.appendChild(document.createTextNode(t(Scan.FILTER_NAMES[f])));
      if (f === draft.suggested) { const tg = document.createElement('span'); tg.className = 'tag'; tg.textContent = t('مقترح'); el.appendChild(tg); }
      el.onclick = () => { draft.filter = f; box.querySelectorAll('.f').forEach((x) => x.classList.toggle('on', x === el)); renderEdit(); };
      box.appendChild(el);
    }
  }
  function renderEdit(withThumbs) {
    if (!draft || !prev) return;
    let out = Scan.applyFilter(prev, draft.filter, draft.bright, draft.contrast);
    if (draft.rot) out = Scan.rotate90(out, draft.rot);
    const c = $('editCanvas'), st = c.parentElement;
    c.width = out.width; c.height = out.height;
    const aw = st.clientWidth - 24, ah = st.clientHeight - 24, k = Math.min(aw / out.width, ah / out.height);
    c.style.width = Math.max(1, out.width * k) + 'px'; c.style.height = Math.max(1, out.height * k) + 'px';
    c.getContext('2d').putImageData(new ImageData(out.data, out.width, out.height), 0, 0);
    if (withThumbs) renderThumbs();
  }
  let raf = 0;
  function liveRender() { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => renderEdit()); }
  $('sBright').oninput = (e) => { draft.bright = +e.target.value; $('vBright').textContent = draft.bright; liveRender(); };
  $('sContrast').oninput = (e) => { draft.contrast = +e.target.value; $('vContrast').textContent = draft.contrast; liveRender(); };
  $('tAdj').onclick = () => $('sliders').classList.toggle('on');
  $('tRot').onclick = () => { draft.rot = (draft.rot + 1) % 4; renderEdit(); };
  $('tCrop').onclick = () => {
    draft.quadBefore = draft.quad.map((p) => p.slice());
    draft.fromEdit = true;
    show('crop');
    $('cropHint').textContent = t('اسحب الدوائر لضبط الحواف بدقة');
    requestAnimationFrame(layoutCrop);
  };
  $('editBack').onclick = () => {
    $('sliders').classList.remove('on');
    if (draft.pageId) { draft = null; prev = null; openDoc(doc.id); }
    else { show('crop'); requestAnimationFrame(layoutCrop); }
  };
  $('editDone').onclick = async () => {
    if (mode === 'id' && !draft.pageId) return idStep();
    busy(true, t('جارٍ حفظ الصفحة…'));
    await frame();
    try {
      if (!draft.pageId) await ensureDoc();
      await savePage(draft);
      draft = null; prev = null; thumbBase = null;
      $('sliders').classList.remove('on');
      busy(false);
      openDoc(doc.id);
    } catch (e) {
      busy(false); toast(t('تعذّر حفظ الصفحة'));
    }
  };

  async function idStep() {
    busy(true, t('جارٍ التجهيز…'));
    await frame();
    let out = Scan.applyFilter(draft.warped, draft.filter, draft.bright, draft.contrast);
    if (draft.rot) out = Scan.rotate90(out, draft.rot);
    const side = dataToCanvas(out);
    draft = null; prev = null; thumbBase = null;
    $('sliders').classList.remove('on');
    if (!idFront) {
      idFront = side;
      busy(false);
      const ok = await dialog({ title: t('الآن الوجه الخلفي'), text: t('اقلب البطاقة وصوّر الوجه الخلفي.'), yes: t('تصوير') });
      if (ok) openCam(); else { mode = null; idFront = null; show('home'); renderHome(); }
      return;
    }
    try {
      const page = await composeId(idFront, side);
      idFront = null; mode = null;
      pickFor = 'new'; await ensureDoc();
      doc.name = t('بطاقة هوية ') + dateFmt.format(new Date()); await DB.put('docs', doc);
      await savePage({ pageId: null, src: page, quad: fullQuad(page), filter: 'original', bright: 0, contrast: 0, rot: 0, warped: imgData(page) });
      busy(false);
      openDoc(doc.id);
    } catch (e) { busy(false); toast(t('تعذّر إنشاء الصفحة')); }
  }

  /* builds the final page images and stores them */
  async function savePage(d) {
    let out = Scan.applyFilter(d.warped, d.filter, d.bright, d.contrast);
    if (d.rot) out = Scan.rotate90(out, d.rot);
    const oc = dataToCanvas(out);
    const outBlob = await toBlob(oc, 0.88);
    const thumb = await toBlob(scaled(oc, 320), 0.8);
    const page = d.pageId ? await DB.get('pages', d.pageId) : { id: uid() };
    if (!d.pageId || d.srcChanged !== false) page.src = await toBlob(d.src, 0.9);
    Object.assign(page, {
      srcW: d.src.width, srcH: d.src.height, quad: d.quad, filter: d.filter, bright: d.bright, contrast: d.contrast, rot: d.rot,
      out: outBlob, outW: oc.width, outH: oc.height, thumb
    });
    oc.width = 0;
    await DB.put('pages', page);
    if (!d.pageId) doc.pages.push(page.id);
    doc.updated = Date.now();
    await DB.put('docs', doc);
  }

  async function editPage(id) {
    busy(true, t('جارٍ فتح الصفحة…'));
    await frame();
    try {
      const p = await DB.get('pages', id);
      const src = await blobToCanvas(p.src, SRC_CAP);
      const sx = src.width / p.srcW, sy = src.height / p.srcH;
      draft = {
        pageId: id, src, quad: p.quad.map((q) => [q[0] * sx, q[1] * sy]), filter: p.filter,
        bright: p.bright || 0, contrast: p.contrast || 0, rot: p.rot || 0, srcChanged: false
      };
      draft.warped = Scan.warp(imgData(src), draft.quad, OUT_CAP);
      draft.suggested = Scan.suggest(draft.warped);
      prepEdit();
      busy(false);
      show('edit');
      renderEdit(true);
    } catch (e) { busy(false); toast(t('تعذّر فتح الصفحة')); }
  }

  /* ================= document screen ================= */
  async function openDoc(id) {
    doc = await DB.get('docs', id);
    if (!doc) { show('home'); renderHome(); return; }
    pickFor = 'add';
    show('doc');
    $('docName').value = doc.name;
    $('docBarTitle').textContent = pagesWord(doc.pages.length);
    freeUrls();
    const box = $('pages'); box.innerHTML = '';
    for (let i = 0; i < doc.pages.length; i++) {
      const p = await DB.get('pages', doc.pages[i]);
      if (!p) continue;
      const el = document.createElement('div');
      el.className = 'pg';
      el.innerHTML = '<img alt=""><span class="n">' + (i + 1) + '</span><div class="row">' +
        t('<button data-a="up" aria-label="تقديم"><svg class="i"><use href="#i-back"/></svg></button>') +
        t('<button data-a="edit" aria-label="تعديل"><svg class="i"><use href="#i-edit"/></svg></button>') +
        t('<button data-a="del" aria-label="حذف"><svg class="i"><use href="#i-trash"/></svg></button>') +
        t('<button data-a="down" aria-label="تأخير"><svg class="i"><use href="#i-right"/></svg></button></div>');
      el.querySelector('img').src = urlOf(p.thumb);
      el.querySelector('img').onclick = () => editPage(p.id);
      el.querySelectorAll('.row button').forEach((b) => { b.onclick = () => pageAction(b.dataset.a, i); });
      if (i === 0) el.querySelector('[data-a=up]').style.visibility = 'hidden';
      if (i === doc.pages.length - 1) el.querySelector('[data-a=down]').style.visibility = 'hidden';
      box.appendChild(el);
    }
    const add = document.createElement('button');
    add.className = 'addpg';
    const full = !pro && doc.pages.length >= FREE_PAGES;
    add.innerHTML = '<svg class="i" style="width:32px;height:32px"><use href="#i-' + (full ? 'lock' : 'plus') + t('"/></svg>إضافة صفحة') + (full ? '<b class="pro-mini">PRO</b>' : '');
    add.onclick = () => { pickFor = 'add'; if (full) openPro('pages'); else openSheet('addSheet'); };
    box.appendChild(add);
    $('saveBtn').disabled = $('shareBtn').disabled = !doc.pages.length;
  }
  async function pageAction(a, i) {
    if (a === 'edit') return editPage(doc.pages[i]);
    if (a === 'up' && i > 0) [doc.pages[i - 1], doc.pages[i]] = [doc.pages[i], doc.pages[i - 1]];
    else if (a === 'down' && i < doc.pages.length - 1) [doc.pages[i + 1], doc.pages[i]] = [doc.pages[i], doc.pages[i + 1]];
    else if (a === 'del') {
      const ok = await dialog({ title: t('حذف الصفحة ') + (i + 1) + t('؟'), text: t('لا يمكن التراجع عن الحذف.'), yes: t('حذف'), danger: true });
      if (!ok) return;
      await DB.del('pages', doc.pages[i]);
      doc.pages.splice(i, 1);
    }
    doc.updated = Date.now();
    await DB.put('docs', doc);
    const y = document.querySelector('#doc .content').scrollTop;
    await openDoc(doc.id);
    document.querySelector('#doc .content').scrollTop = y;
  }
  $('docName').onchange = async () => {
    const v = $('docName').value.trim();
    if (!v) { $('docName').value = doc.name; return; }
    doc.name = v; doc.updated = Date.now(); await DB.put('docs', doc);
  };
  $('docName').onkeydown = (e) => { if (e.key === 'Enter') e.target.blur(); };
  $('docBack').onclick = async () => {
    if (doc && !doc.pages.length) await DB.del('docs', doc.id);
    doc = null; pickFor = 'new';
    show('home'); renderHome();
  };
  $('docMore').onclick = () => docMenu(doc, true);

  /* ================= doc menu ================= */
  let menuDoc = null;
  function docMenu(d, inside) {
    menuDoc = d;
    $('docSheetTitle').textContent = d.name;
    $('dmOpen').classList.toggle('hidden', inside);
    openSheet('docSheet');
  }
  $('dmOpen').onclick = () => { closeSheet(); openDoc(menuDoc.id); };
  $('dmShare').onclick = async () => { closeSheet(); doc = await DB.get('docs', menuDoc.id); openExport('share'); };
  $('dmRename').onclick = async () => {
    const v = await dialog({ title: t('إعادة التسمية'), input: menuDoc.name, yes: t('حفظ') });
    if (!v) return;
    const d = await DB.get('docs', menuDoc.id); d.name = v; d.updated = Date.now(); await DB.put('docs', d);
    if (current === 'doc') { doc = d; $('docName').value = v; } else renderHome();
  };
  $('dmCopy').onclick = async () => {
    closeSheet();
    const d = await DB.get('docs', menuDoc.id);
    const nd = { id: uid(), name: d.name + t(' (نسخة)'), created: Date.now(), updated: Date.now(), pages: [] };
    for (const pid of d.pages) { const p = await DB.get('pages', pid); if (!p) continue; p.id = uid(); await DB.put('pages', p); nd.pages.push(p.id); }
    await DB.put('docs', nd);
    toast(t('تم إنشاء نسخة'));
    if (current === 'doc') openDoc(nd.id); else renderHome();
  };
  $('dmDelete').onclick = async () => {
    const ok = await dialog({ title: t('حذف «') + menuDoc.name + t('»؟'), text: t('سيتم حذف المستند وكل صفحاته نهائياً.'), yes: t('حذف'), danger: true });
    if (!ok) return;
    const d = await DB.get('docs', menuDoc.id);
    for (const pid of d.pages) await DB.del('pages', pid);
    await DB.del('docs', d.id);
    toast(t('تم حذف المستند'));
    doc = null; pickFor = 'new'; show('home'); renderHome();
  };

  /* ================= export ================= */
  const QUALITY = { high: { cap: 2400, q: 0.88 }, mid: { cap: 1700, q: 0.78 }, small: { cap: 1200, q: 0.62 } };
  const pref = { quality: 'mid', size: 'auto', target: '1000' };
  let lockPdf = false;
  try { Object.assign(pref, JSON.parse(localStorage.getItem('exportPref') || '{}')); } catch (e) { }
  function segInit(id, key) {
    const seg = $(id);
    seg.querySelectorAll('button').forEach((b) => {
      b.classList.toggle('on', b.dataset.v === pref[key]);
      b.onclick = () => {
        if (b.dataset.v === 'target' && !pro) { openPro('target'); return; }
        pref[key] = b.dataset.v;
        seg.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
        try { localStorage.setItem('exportPref', JSON.stringify(pref)); } catch (e) { }
        $('segTarget').classList.toggle('hidden', pref.quality !== 'target');
      };
    });
  }
  segInit('segQuality', 'quality'); segInit('segSize', 'size'); segInit('segTarget', 'target');
  $('lockToggle').onclick = () => needPro('lock', () => { lockPdf = !lockPdf; $('lockToggle').classList.toggle('on', lockPdf); });
  let exportMode = 'save';
  function openExport(mode) {
    exportMode = mode;
    $('exportTitle').textContent = mode === 'share' ? t('مشاركة المستند') : t('حفظ المستند');
    $('fileName').value = doc.name;
    $('fileExt').textContent = '.pdf';
    $('estSize').textContent = pagesWord(doc.pages.length) + (pro || !PLAY ? '' : t(' · بعلامة NEXA Scan المائية'));
    if (pref.quality === 'target' && !pro) pref.quality = 'mid';
    document.querySelectorAll('#segQuality button').forEach((b) => b.classList.toggle('on', b.dataset.v === pref.quality));
    $('segTarget').classList.toggle('hidden', pref.quality !== 'target');
    if (!pro) lockPdf = false;
    $('lockToggle').classList.toggle('on', lockPdf);
    openSheet('exportSheet');
  }
  $('saveBtn').onclick = () => openExport('save');
  $('shareBtn').onclick = () => openExport('share');
  $('fileName').onkeydown = (e) => { if (e.key === 'Enter') e.target.blur(); };
  async function takeName() {
    const v = $('fileName').value.trim();
    if (!v) { toast(t('اكتب اسماً للملف')); $('fileName').focus(); return false; }
    if (v !== doc.name) {
      doc.name = v; doc.updated = Date.now(); await DB.put('docs', doc);
      if (current === 'doc') $('docName').value = v;
    }
    return true;
  }
  $('exPdf').onclick = async () => {
    if (!(await takeName())) return;
    let pw = null;
    if (lockPdf && pro) {
      pw = await dialog({ title: t('كلمة سر الملف'), text: t('سيُطلب هذا الرمز عند فتح الملف. استخدم أحرفاً إنجليزية وأرقاماً.'), input: '', yes: t('قفل وحفظ') });
      if (!pw) return;
      if (!/^[\x21-\x7E]{4,32}$/.test(pw)) { toast(t('كلمة السر من 4 إلى 32 حرفاً إنجليزياً أو رقماً')); return; }
    } else closeSheet();
    exportDoc('pdf', exportMode, pw);
  };
  $('exJpg').onclick = async () => { if (!(await takeName())) return; closeSheet(); exportDoc('jpg', exportMode); };

  const safeName = (s) => (s || 'NEXA Scan').replace(/[\\/:*?"<>|]+/g, ' ').trim().slice(0, 60) || 'NEXA Scan';

  /* small «NEXA Scan» mark in the corner of free-version exports */
  function watermark(c) {
    const x = c.getContext('2d'), u = Math.max(c.width, c.height) / 100;
    const fs = Math.max(12, Math.round(u * 1.5));
    x.font = '600 ' + fs + 'px Plex, sans-serif';
    x.direction = 'ltr';
    const text = 'Scanned with NEXA Scan', tw = x.measureText(text).width;
    const padX = fs * 0.7, h = fs * 1.9, w = tw + padX * 2, m = u * 1.2;
    const bx = c.width - w - m, by = c.height - h - m;
    x.globalAlpha = 0.82; x.fillStyle = '#16325C';
    x.beginPath();
    if (x.roundRect) x.roundRect(bx, by, w, h, h / 2); else x.rect(bx, by, w, h);
    x.fill();
    x.globalAlpha = 1; x.fillStyle = '#fff'; x.textBaseline = 'middle';
    x.fillText(text, bx + padX, by + h / 2 + fs * 0.05);
  }

  async function pageCanvases(cap) {
    const out = [];
    for (let i = 0; i < doc.pages.length; i++) {
      busy(true, t('جارٍ تجهيز الصفحة ') + (i + 1) + t(' من ') + doc.pages.length + '…');
      await frame();
      const p = await DB.get('pages', doc.pages[i]);
      const c = await blobToCanvas(p.out, cap);
      if (PLAY && !pro) watermark(c);
      out.push(c);
    }
    return out;
  }
  async function encodeAll(canvases, cap, q) {
    const out = [];
    for (const c of canvases) {
      const s = cap >= Math.max(c.width, c.height) ? c : scaled(c, cap);
      const blob = await toBlob(s, q);
      out.push({ blob, width: s.width, height: s.height });
    }
    return out;
  }
  async function renderPagesForExport(cfg) {
    const cs = await pageCanvases(cfg.cap);
    const out = await encodeAll(cs, cfg.cap, cfg.q);
    cs.forEach((c) => { c.width = 0; });
    return out;
  }
  /* tries smaller sizes until the whole file fits under the target */
  async function renderToTarget(targetKB) {
    const limit = targetKB * 1024 - 2048 - doc.pages.length * 600;
    const cs = await pageCanvases(2000);
    busy(true, t('جارٍ ضغط الملف…'));
    const steps = [[2000, 0.82], [1700, 0.75], [1500, 0.68], [1300, 0.62], [1150, 0.55], [1000, 0.5], [850, 0.45], [720, 0.4], [600, 0.35], [500, 0.3]];
    let best = null;
    for (const [cap, q] of steps) {
      await frame();
      const r = await encodeAll(cs, cap, q);
      const size = r.reduce((a, p) => a + p.blob.size, 0);
      best = r;
      if (size <= limit) break;
    }
    cs.forEach((c) => { c.width = 0; });
    const total = best.reduce((a, p) => a + p.blob.size, 0);
    if (total > limit) toast(t('تعذّر الوصول للحجم المطلوب، هذا أصغر حجم ممكن'));
    return best;
  }

  async function exportDoc(kind, mode, password) {
    if (!doc || !doc.pages.length) return;
    const target = pref.quality === 'target' && pro;
    const cfg = QUALITY[pref.quality] || QUALITY.mid;
    maybeInterstitial();
    try {
      const pages = target ? await renderToTarget(+pref.target || 1000) : await renderPagesForExport(cfg);
      busy(true, t('جارٍ إنشاء الملف…'));
      await frame();
      const base = safeName(doc.name);
      let files;
      if (kind === 'pdf') {
        const arr = [];
        for (const p of pages) arr.push({ jpeg: new Uint8Array(await p.blob.arrayBuffer()), width: p.width, height: p.height });
        const bytes = Scan.makePdf(arr, pref.size, doc.name, password || null);
        files = [{ name: base + '.pdf', blob: new Blob([bytes], { type: 'application/pdf' }), mime: 'application/pdf' }];
      } else {
        files = pages.map((p, i) => ({ name: base + (pages.length > 1 ? ' - ' + (i + 1) : '') + '.jpg', blob: p.blob, mime: 'image/jpeg' }));
      }
      await deliver(files, mode);
    } catch (e) {
      if (e && e.name === 'AbortError') { busy(false); return; }
      busy(false); toast(t('تعذّر إنشاء الملف'));
    }
  }

  function b64(buf) {
    const bytes = new Uint8Array(buf); let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }

  async function deliver(files, mode) {
    if (isAndroidApp) {
      const ids = [];
      for (const f of files) {
        const buf = await f.blob.arrayBuffer();
        const id = Android.beginFile(f.name, f.mime);
        const CH = 3 * 256 * 1024;
        for (let o = 0; o < buf.byteLength; o += CH) Android.appendChunk(id, b64(buf.slice(o, o + CH)));
        ids.push(id);
      }
      busy(false);
      const msg = Android.finishFiles(JSON.stringify(ids), mode);
      if (msg) toast(msg);
      return;
    }
    const fileObjs = files.map((f) => new File([f.blob], f.name, { type: f.mime }));
    const canShare = navigator.canShare && navigator.canShare({ files: fileObjs });
    busy(false);
    if (canShare && (mode === 'share' || isIOS)) {
      try { await navigator.share({ files: fileObjs, title: doc.name }); }
      catch (e) { if (e.name !== 'AbortError') downloadAll(files); }
      return;
    }
    if (mode === 'share' && !canShare) toast(t('المشاركة غير مدعومة في هذا المتصفح، تم تنزيل الملف'));
    downloadAll(files);
  }
  function downloadAll(files) {
    files.forEach((f, i) => setTimeout(() => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(f.blob); a.download = f.name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    }, i * 400));
    toast(files.length > 1 ? t('تم تنزيل ') + files.length + t(' صور') : t('تم تنزيل الملف'));
  }

  /* ================= back button (Android) ================= */
  window.nexaBack = function () {
    if (dlgOpen) { dlgClose(false); return true; }
    if (openSheetEl) { closeSheet(); return true; }
    if ($('busy').classList.contains('on')) return true;
    if (current === 'crop') { $('cropBack').onclick(); return true; }
    if (current === 'edit') { $('editBack').onclick(); return true; }
    if (current === 'doc') { $('docBack').onclick(); return true; }
    if (current === 'pro') { closePro(); return true; }
    if (current === 'burst') { $('burstDone').onclick(); return true; }
    return false;
  };

  /* ================= start ================= */
  applyPro();
  DB.open().then(renderHome).catch(() => toast(t('تعذّر فتح التخزين')));
  if ('serviceWorker' in navigator && !isAndroidApp && location.protocol === 'https:') {
    navigator.serviceWorker.register('sw.js').catch(() => { });
  }
})();
