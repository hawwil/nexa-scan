/* NEXA Scan — app logic */
(function () {
  'use strict';
  const VERSION = '1.1';
  const $ = (id) => document.getElementById(id);
  const isAndroidApp = typeof window.Android !== 'undefined';
  const isIOS = /iP(hone|ad|od)/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const SRC_CAP = 3000, OUT_CAP = 2400;

  /* ================= storage (IndexedDB) ================= */
  const DB = {
    db: null,
    open() {
      return new Promise((res, rej) => {
        const r = indexedDB.open('nexa-scan', 1);
        r.onupgradeneeded = () => {
          const d = r.result;
          d.createObjectStore('docs', { keyPath: 'id' });
          d.createObjectStore('pages', { keyPath: 'id' });
        };
        r.onsuccess = () => { DB.db = r.result; res(); };
        r.onerror = () => rej(r.error);
      });
    },
    tx(store, mode, fn) {
      return new Promise((res, rej) => {
        const t = DB.db.transaction(store, mode), s = t.objectStore(store);
        const r = fn(s);
        t.oncomplete = () => res(r && r.result);
        t.onerror = () => rej(t.error);
        t.onabort = () => rej(t.error);
      });
    },
    get: (s, k) => DB.tx(s, 'readonly', (st) => st.get(k)),
    put: (s, v) => DB.tx(s, 'readwrite', (st) => st.put(v)),
    del: (s, k) => DB.tx(s, 'readwrite', (st) => st.delete(k)),
    all: (s) => DB.tx(s, 'readonly', (st) => st.getAll())
  };
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

  /* ================= ui helpers ================= */
  function show(id) {
    document.querySelectorAll('.screen').forEach((s) => s.classList.toggle('on', s.id === id));
    current = id;
    if (isAndroidApp && Android.setDark) { try { Android.setDark(id === 'crop' || id === 'edit'); } catch (e) { } }
  }
  let current = 'home';
  let toastT = 0;
  function toast(msg) {
    const t = $('toast'); t.textContent = msg; t.classList.add('on');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600);
  }
  window.nexaToast = (m) => toast(m);
  function busy(on, text) { $('busy').classList.toggle('on', !!on); if (text) $('busyText').textContent = text; }
  const frame = () => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 0)));
  let openSheetEl = null;
  function openSheet(id) { closeSheet(); openSheetEl = $(id); $('veil').classList.add('on'); openSheetEl.classList.add('on'); }
  function closeSheet() { if (openSheetEl) openSheetEl.classList.remove('on'); openSheetEl = null; if (!dlgOpen) $('veil').classList.remove('on'); }
  $('veil').onclick = () => { if (dlgOpen) dlgClose(false); else closeSheet(); };

  let dlgOpen = null;
  function dialog({ title, text, input, yes, danger }) {
    return new Promise((res) => {
      closeSheet();
      $('dlgTitle').textContent = title; $('dlgText').textContent = text || '';
      $('dlgText').classList.toggle('hidden', !text);
      const inp = $('dlgInput');
      inp.classList.toggle('hidden', input === undefined);
      if (input !== undefined) inp.value = input;
      $('dlgYes').textContent = yes || 'موافق';
      $('dlgYes').className = 'btn ' + (danger ? 'danger' : 'primary');
      $('dlg').classList.add('on'); $('veil').classList.add('on');
      dlgOpen = res;
      if (input !== undefined) setTimeout(() => { inp.focus(); inp.select(); }, 50);
    });
  }
  function dlgClose(ok) {
    const res = dlgOpen; dlgOpen = null;
    $('dlg').classList.remove('on'); $('veil').classList.remove('on');
    if (res) res(ok ? ($('dlgInput').classList.contains('hidden') ? true : $('dlgInput').value.trim()) : false);
  }
  $('dlgYes').onclick = () => dlgClose(true);
  $('dlgNo').onclick = () => dlgClose(false);

  const dateFmt = new Intl.DateTimeFormat('ar-u-nu-latn', { day: 'numeric', month: 'long', year: 'numeric' });
  const timeFmt = new Intl.DateTimeFormat('ar-u-nu-latn', { hour: 'numeric', minute: '2-digit' });
  function defaultName() {
    const d = new Date();
    return 'مستند ' + dateFmt.format(d) + '، ' + timeFmt.format(d);
  }
  const pagesWord = (n) => n === 1 ? 'صفحة واحدة' : n === 2 ? 'صفحتان' : n <= 10 ? n + ' صفحات' : n + ' صفحة';

  function footer() {
    return 'تم التطوير من <a href="https://instagram.com/nexa.ryx" target="_blank" rel="noopener">NEXA</a> للخدمات الرقمية<br>' +
      '© NEXA ' + new Date().getFullYear() + ' · جميع الحقوق محفوظة<br>الإصدار ' + VERSION;
  }
  $('footer1').innerHTML = footer();
  $('footer2').innerHTML = footer();

  /* ================= image helpers ================= */
  function canvasOf(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  function loadImg(src) {
    return new Promise((res, rej) => {
      const url = typeof src === 'string' ? src : URL.createObjectURL(src);
      const i = new Image();
      i.onload = () => { if (typeof src !== 'string') URL.revokeObjectURL(url); res(i); };
      i.onerror = () => { if (typeof src !== 'string') URL.revokeObjectURL(url); rej(new Error('img')); };
      i.src = url;
    });
  }
  async function blobToCanvas(blob, cap) {
    const img = await loadImg(blob);
    const s = Math.min(1, cap / Math.max(img.naturalWidth, img.naturalHeight));
    const c = canvasOf(Math.round(img.naturalWidth * s), Math.round(img.naturalHeight * s));
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    return c;
  }
  function scaled(canvasOrImg, cap) {
    const w = canvasOrImg.width, h = canvasOrImg.height, s = Math.min(1, cap / Math.max(w, h));
    const c = canvasOf(Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s)));
    const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(canvasOrImg, 0, 0, c.width, c.height);
    return c;
  }
  const imgData = (c) => c.getContext('2d').getImageData(0, 0, c.width, c.height);
  function dataToCanvas(d) {
    const c = canvasOf(d.width, d.height);
    c.getContext('2d').putImageData(new ImageData(d.data, d.width, d.height), 0, 0);
    return c;
  }
  const toBlob = (c, q) => new Promise((r) => c.toBlob(r, 'image/jpeg', q));
  function detectQuad(src) {
    const small = scaled(src, 400), s = small.width / src.width;
    const r = Scan.detect(imgData(small));
    let quad = r.quad.map((p) => [p[0] / s, p[1] / s]);
    if (r.found) {
      try {
        const mid = scaled(src, 1000), m = mid.width / src.width;
        quad = Scan.refine(imgData(mid), quad.map((p) => [p[0] * m, p[1] * m])).map((p) => [p[0] / m, p[1] / m]);
      } catch (e) { /* keep rough quad */ }
    }
    return { found: r.found, quad };
  }
  const fullQuad = (c) => [[0, 0], [c.width, 0], [c.width, c.height], [0, c.height]];

  /* ================= state ================= */
  let doc = null;           // open document
  let draft = null;         // page being made/edited
  let pickFor = 'new';      // where picked images go

  /* ================= home ================= */
  const urls = [];
  function freeUrls() { while (urls.length) URL.revokeObjectURL(urls.pop()); }
  const urlOf = (blob) => { const u = URL.createObjectURL(blob); urls.push(u); return u; };

  async function renderHome() {
    freeUrls();
    const docs = (await DB.all('docs')).sort((a, b) => b.updated - a.updated);
    const q = $('q').value.trim();
    const list = q ? docs.filter((d) => d.name.includes(q)) : docs;
    const box = $('docList');
    box.innerHTML = '';
    $('empty').classList.toggle('hidden', docs.length > 0);
    if (q && !list.length) box.innerHTML = '<div class="empty" style="padding-top:20px">لا توجد نتائج لـ «' + q.replace(/[<>&]/g, '') + '»</div>';
    for (const d of list) {
      const first = d.pages.length ? await DB.get('pages', d.pages[0]) : null;
      const el = document.createElement('div');
      el.className = 'doc';
      const dt = new Date(d.updated);
      el.innerHTML = '<img alt=""><div class="meta"><b></b><span></span></div><button class="more"><svg class="i"><use href="#i-more"/></svg></button>';
      if (first && first.thumb) el.querySelector('img').src = urlOf(first.thumb);
      el.querySelector('b').textContent = d.name;
      el.querySelector('span').textContent = pagesWord(d.pages.length) + ' · ' + dateFmt.format(dt) + ' ' + timeFmt.format(dt);
      el.onclick = () => openDoc(d.id);
      el.querySelector('.more').onclick = (e) => { e.stopPropagation(); docMenu(d, false); };
      box.appendChild(el);
    }
  }
  $('q').oninput = () => renderHome();

  if (isIOS && !navigator.standalone && !isAndroidApp) {
    try { if (!localStorage.getItem('iosTipHidden')) $('iosTip').classList.remove('hidden'); } catch (e) { $('iosTip').classList.remove('hidden'); }
  }
  $('iosTipX').onclick = () => { $('iosTip').classList.add('hidden'); try { localStorage.setItem('iosTipHidden', '1'); } catch (e) { } };

  /* ================= picking images ================= */
  document.querySelectorAll('[data-pick]').forEach((b) => {
    b.onclick = () => {
      if (b.closest('.sheet')) closeSheet(); else pickFor = 'new';
      if (b.dataset.pick === 'camera') { $('fCam').value = ''; $('fCam').click(); }
      else { $('fGal').value = ''; $('fGal').click(); }
    };
  });
  $('fCam').onchange = (e) => { const f = e.target.files[0]; if (f) startDraft(f); };
  $('fGal').onchange = (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 1) startDraft(files[0]);
    else if (files.length > 1) batchImport(files);
  };

  async function ensureDoc() {
    if (pickFor === 'new' || !doc) {
      doc = { id: uid(), name: defaultName(), created: Date.now(), updated: Date.now(), pages: [] };
      await DB.put('docs', doc);
    }
  }

  async function startDraft(file) {
    busy(true, 'جارٍ تجهيز الصورة…');
    await frame();
    try {
      const src = await blobToCanvas(file, SRC_CAP);
      const d = detectQuad(src);
      draft = { pageId: null, src, quad: d.quad, found: d.found, filter: null, bright: 0, contrast: 0, rot: 0, fromEdit: false };
      busy(false);
      openCrop();
    } catch (e) {
      busy(false); toast('تعذّر فتح الصورة');
    }
  }

  async function batchImport(files) {
    await ensureDoc();
    let done = 0;
    for (let i = 0; i < files.length; i++) {
      busy(true, 'جارٍ معالجة الصورة ' + (i + 1) + ' من ' + files.length + '…');
      await frame();
      try {
        const src = await blobToCanvas(files[i], SRC_CAP);
        const d = detectQuad(src);
        const warped = Scan.warp(imgData(src), d.quad, OUT_CAP);
        const filter = Scan.suggest(warped);
        await savePage({ pageId: null, src, quad: d.quad, filter, bright: 0, contrast: 0, rot: 0, warped });
        done++;
      } catch (e) { /* skip unreadable */ }
    }
    busy(false);
    if (done < files.length) toast('تعذّر فتح ' + (files.length - done) + ' من الصور');
    openDoc(doc.id);
  }

  /* ================= crop screen ================= */
  const crop = { scale: 1, ox: 0, oy: 0, drag: -1 };
  function openCrop() {
    show('crop');
    $('cropHint').textContent = draft.found ? 'اسحب الدوائر لضبط الحواف بدقة' : 'لم نتمكن من تحديد الورقة تلقائياً، اسحب الدوائر إلى زوايا الورقة';
    requestAnimationFrame(layoutCrop);
  }
  function layoutCrop() {
    const st = $('cropStage'), W = st.clientWidth, H = st.clientHeight, pad = 26;
    const src = draft.src;
    const s = Math.min((W - pad * 2) / src.width, (H - pad * 2) / src.height);
    crop.scale = s; crop.ox = (W - src.width * s) / 2; crop.oy = (H - src.height * s) / 2;
    const c = $('cropCanvas'), dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = Math.round(src.width * s * dpr); c.height = Math.round(src.height * s * dpr);
    c.style.width = src.width * s + 'px'; c.style.height = src.height * s + 'px';
    c.style.left = crop.ox + 'px'; c.style.top = crop.oy + 'px';
    const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(src, 0, 0, c.width, c.height);
    st.querySelectorAll('.handle').forEach((h) => h.remove());
    for (let i = 0; i < 4; i++) {
      const h = document.createElement('div'); h.className = 'handle'; h.dataset.i = i;
      h.addEventListener('pointerdown', handleDown);
      st.appendChild(h);
    }
    drawCrop();
  }
  function drawCrop() {
    const st = $('cropStage'), W = st.clientWidth, H = st.clientHeight;
    const pts = draft.quad.map((p) => [crop.ox + p[0] * crop.scale, crop.oy + p[1] * crop.scale]);
    const poly = pts.map((p) => p.join(',')).join(' ');
    $('cropOv').innerHTML =
      '<path fill="rgba(5,10,20,.55)" fill-rule="evenodd" d="M0 0H' + W + 'V' + H + 'H0Z M' + pts.map((p) => p.join(' ')).join(' L') + 'Z"/>' +
      '<polygon points="' + poly + '" fill="none" stroke="#1FB6C9" stroke-width="2.5" stroke-linejoin="round"/>';
    st.querySelectorAll('.handle').forEach((h, i) => { h.style.left = pts[i][0] + 'px'; h.style.top = pts[i][1] + 'px'; });
  }
  function handleDown(e) {
    e.preventDefault();
    crop.drag = +e.currentTarget.dataset.i;
    const st = $('cropStage'), r = st.getBoundingClientRect();
    const p = draft.quad[crop.drag];
    crop.grab = [e.clientX - r.left - (crop.ox + p[0] * crop.scale), e.clientY - r.top - (crop.oy + p[1] * crop.scale)];
    e.currentTarget.setPointerCapture(e.pointerId);
    e.currentTarget.onpointermove = handleMove;
    e.currentTarget.onpointerup = e.currentTarget.onpointercancel = handleUp;
    handleMove(e);
  }
  function handleMove(e) {
    if (crop.drag < 0) return;
    const st = $('cropStage'), r = st.getBoundingClientRect();
    const sx = e.clientX - r.left - crop.grab[0], sy = e.clientY - r.top - crop.grab[1];
    const ix = Math.max(0, Math.min(draft.src.width, (sx - crop.ox) / crop.scale));
    const iy = Math.max(0, Math.min(draft.src.height, (sy - crop.oy) / crop.scale));
    draft.quad[crop.drag] = [ix, iy];
    drawCrop();
    // loupe
    const L = $('loupe'), lc = $('loupeCanvas'), x = lc.getContext('2d');
    const zoom = 2.6 * crop.scale, size = 110;
    x.fillStyle = '#000'; x.fillRect(0, 0, size, size);
    x.drawImage(draft.src, ix - size / 2 / zoom, iy - size / 2 / zoom, size / zoom, size / zoom, 0, 0, size, size);
    // draw neighbouring edges inside the loupe
    x.strokeStyle = '#1FB6C9'; x.lineWidth = 2; x.beginPath();
    const q = draft.quad, i = crop.drag, a = q[(i + 3) % 4], b = q[(i + 1) % 4];
    const m = (p) => [size / 2 + (p[0] - ix) * zoom, size / 2 + (p[1] - iy) * zoom];
    x.moveTo(...m(a)); x.lineTo(size / 2, size / 2); x.lineTo(...m(b)); x.stroke();
    L.style.display = 'block';
    const px = crop.ox + ix * crop.scale, py = crop.oy + iy * crop.scale;
    let ly = py - 150; if (ly < 4) ly = py + 50;
    let lx = px - 55; lx = Math.max(4, Math.min(st.clientWidth - 114, lx));
    L.style.left = lx + 'px'; L.style.top = ly + 'px';
  }
  function handleUp(e) {
    crop.drag = -1; $('loupe').style.display = 'none';
    e.currentTarget.onpointermove = null;
  }
  window.addEventListener('resize', () => { if (current === 'crop') layoutCrop(); else if (current === 'edit') renderEdit(); });

  $('tAuto').onclick = () => {
    const d = detectQuad(draft.src);
    draft.quad = d.quad; drawCrop();
    toast(d.found ? 'تم تحديد الورقة' : 'لم يتم العثور على حواف واضحة');
  };
  $('tFull').onclick = () => { draft.quad = fullQuad(draft.src); drawCrop(); };
  $('cropRetake').onclick = () => {
    if (draft.fromEdit) { $('cropBack').onclick(); return; }
    $('fCam').value = ''; $('fCam').click();
  };
  $('cropBack').onclick = () => {
    if (draft && draft.fromEdit) { draft.quad = draft.quadBefore; draft.fromEdit = false; show('edit'); renderEdit(); return; }
    draft = null;
    if (doc && pickFor === 'add') openDoc(doc.id); else { show('home'); renderHome(); }
  };
  function quadOk(q) {
    let a = 0;
    for (let i = 0; i < 4; i++) { const p = q[i], n = q[(i + 1) % 4]; a += p[0] * n[1] - n[0] * p[1]; }
    return Math.abs(a / 2) > draft.src.width * draft.src.height * 0.01;
  }
  $('cropNext').onclick = async () => {
    if (!quadOk(draft.quad)) { toast('المنطقة المحددة صغيرة جداً'); return; }
    busy(true, 'جارٍ تصحيح الميلان…');
    await frame();
    draft.warped = Scan.warp(imgData(draft.src), draft.quad, OUT_CAP);
    draft.suggested = Scan.suggest(draft.warped);
    if (!draft.filter) draft.filter = draft.suggested;
    draft.fromEdit = false;
    prepEdit();
    busy(false);
    show('edit');
    renderEdit(true);
  };

  /* ================= edit screen ================= */
  let prev = null, thumbBase = null;
  function prepEdit() {
    const wc = dataToCanvas(draft.warped);
    prev = imgData(scaled(wc, 1100));
    thumbBase = imgData(scaled(wc, 170));
    wc.width = 0;
    $('sBright').value = draft.bright; $('sContrast').value = draft.contrast;
    $('vBright').textContent = draft.bright; $('vContrast').textContent = draft.contrast;
  }
  function renderThumbs() {
    const box = $('filters'); box.innerHTML = '';
    for (const f of Scan.FILTERS) {
      const el = document.createElement('button');
      el.className = 'f' + (f === draft.filter ? ' on' : '');
      const out = Scan.applyFilter(thumbBase, f, 0, 0);
      const c = dataToCanvas(out);
      el.appendChild(c);
      el.appendChild(document.createTextNode(Scan.FILTER_NAMES[f]));
      if (f === draft.suggested) { const t = document.createElement('span'); t.className = 'tag'; t.textContent = 'مقترح'; el.appendChild(t); }
      el.onclick = () => { draft.filter = f; box.querySelectorAll('.f').forEach((x) => x.classList.toggle('on', x === el)); renderEdit(); };
      box.appendChild(el);
    }
  }
  function renderEdit(withThumbs) {
    if (!draft || !prev) return;
    let out = Scan.applyFilter(prev, draft.filter, draft.bright, draft.contrast);
    if (draft.rot) out = Scan.rotate90(out, draft.rot);
    const c = $('editCanvas'), st = c.parentElement;
    c.width = out.width; c.height = out.height;
    const aw = st.clientWidth - 24, ah = st.clientHeight - 24, k = Math.min(aw / out.width, ah / out.height);
    c.style.width = Math.max(1, out.width * k) + 'px'; c.style.height = Math.max(1, out.height * k) + 'px';
    c.getContext('2d').putImageData(new ImageData(out.data, out.width, out.height), 0, 0);
    if (withThumbs) renderThumbs();
  }
  let raf = 0;
  function liveRender() { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => renderEdit()); }
  $('sBright').oninput = (e) => { draft.bright = +e.target.value; $('vBright').textContent = draft.bright; liveRender(); };
  $('sContrast').oninput = (e) => { draft.contrast = +e.target.value; $('vContrast').textContent = draft.contrast; liveRender(); };
  $('tAdj').onclick = () => $('sliders').classList.toggle('on');
  $('tRot').onclick = () => { draft.rot = (draft.rot + 1) % 4; renderEdit(); };
  $('tCrop').onclick = () => {
    draft.quadBefore = draft.quad.map((p) => p.slice());
    draft.fromEdit = true;
    show('crop');
    $('cropHint').textContent = 'اسحب الدوائر لضبط الحواف بدقة';
    requestAnimationFrame(layoutCrop);
  };
  $('editBack').onclick = () => {
    $('sliders').classList.remove('on');
    if (draft.pageId) { draft = null; prev = null; openDoc(doc.id); }
    else { show('crop'); requestAnimationFrame(layoutCrop); }
  };
  $('editDone').onclick = async () => {
    busy(true, 'جارٍ حفظ الصفحة…');
    await frame();
    try {
      if (!draft.pageId) await ensureDoc();
      await savePage(draft);
      draft = null; prev = null; thumbBase = null;
      $('sliders').classList.remove('on');
      busy(false);
      openDoc(doc.id);
    } catch (e) {
      busy(false); toast('تعذّر حفظ الصفحة');
    }
  };

  /* builds the final page images and stores them */
  async function savePage(d) {
    let out = Scan.applyFilter(d.warped, d.filter, d.bright, d.contrast);
    if (d.rot) out = Scan.rotate90(out, d.rot);
    const oc = dataToCanvas(out);
    const outBlob = await toBlob(oc, 0.88);
    const thumb = await toBlob(scaled(oc, 320), 0.8);
    const page = d.pageId ? await DB.get('pages', d.pageId) : { id: uid() };
    if (!d.pageId || d.srcChanged !== false) page.src = await toBlob(d.src, 0.9);
    Object.assign(page, {
      srcW: d.src.width, srcH: d.src.height, quad: d.quad, filter: d.filter, bright: d.bright, contrast: d.contrast, rot: d.rot,
      out: outBlob, outW: oc.width, outH: oc.height, thumb
    });
    oc.width = 0;
    await DB.put('pages', page);
    if (!d.pageId) doc.pages.push(page.id);
    doc.updated = Date.now();
    await DB.put('docs', doc);
  }

  async function editPage(id) {
    busy(true, 'جارٍ فتح الصفحة…');
    await frame();
    try {
      const p = await DB.get('pages', id);
      const src = await blobToCanvas(p.src, SRC_CAP);
      const sx = src.width / p.srcW, sy = src.height / p.srcH;
      draft = {
        pageId: id, src, quad: p.quad.map((q) => [q[0] * sx, q[1] * sy]), filter: p.filter,
        bright: p.bright || 0, contrast: p.contrast || 0, rot: p.rot || 0, srcChanged: false
      };
      draft.warped = Scan.warp(imgData(src), draft.quad, OUT_CAP);
      draft.suggested = Scan.suggest(draft.warped);
      prepEdit();
      busy(false);
      show('edit');
      renderEdit(true);
    } catch (e) { busy(false); toast('تعذّر فتح الصفحة'); }
  }

  /* ================= document screen ================= */
  async function openDoc(id) {
    doc = await DB.get('docs', id);
    if (!doc) { show('home'); renderHome(); return; }
    pickFor = 'add';
    show('doc');
    $('docName').value = doc.name;
    $('docBarTitle').textContent = pagesWord(doc.pages.length);
    freeUrls();
    const box = $('pages'); box.innerHTML = '';
    for (let i = 0; i < doc.pages.length; i++) {
      const p = await DB.get('pages', doc.pages[i]);
      if (!p) continue;
      const el = document.createElement('div');
      el.className = 'pg';
      el.innerHTML = '<img alt=""><span class="n">' + (i + 1) + '</span><div class="row">' +
        '<button data-a="up" aria-label="تقديم"><svg class="i"><use href="#i-back"/></svg></button>' +
        '<button data-a="edit" aria-label="تعديل"><svg class="i"><use href="#i-edit"/></svg></button>' +
        '<button data-a="del" aria-label="حذف"><svg class="i"><use href="#i-trash"/></svg></button>' +
        '<button data-a="down" aria-label="تأخير"><svg class="i"><use href="#i-right"/></svg></button></div>';
      el.querySelector('img').src = urlOf(p.thumb);
      el.querySelector('img').onclick = () => editPage(p.id);
      el.querySelectorAll('.row button').forEach((b) => { b.onclick = () => pageAction(b.dataset.a, i); });
      if (i === 0) el.querySelector('[data-a=up]').style.visibility = 'hidden';
      if (i === doc.pages.length - 1) el.querySelector('[data-a=down]').style.visibility = 'hidden';
      box.appendChild(el);
    }
    const add = document.createElement('button');
    add.className = 'addpg';
    add.innerHTML = '<svg class="i" style="width:32px;height:32px"><use href="#i-plus"/></svg>إضافة صفحة';
    add.onclick = () => { pickFor = 'add'; openSheet('addSheet'); };
    box.appendChild(add);
    $('saveBtn').disabled = $('shareBtn').disabled = !doc.pages.length;
  }
  async function pageAction(a, i) {
    if (a === 'edit') return editPage(doc.pages[i]);
    if (a === 'up' && i > 0) [doc.pages[i - 1], doc.pages[i]] = [doc.pages[i], doc.pages[i - 1]];
    else if (a === 'down' && i < doc.pages.length - 1) [doc.pages[i + 1], doc.pages[i]] = [doc.pages[i], doc.pages[i + 1]];
    else if (a === 'del') {
      const ok = await dialog({ title: 'حذف الصفحة ' + (i + 1) + '؟', text: 'لا يمكن التراجع عن الحذف.', yes: 'حذف', danger: true });
      if (!ok) return;
      await DB.del('pages', doc.pages[i]);
      doc.pages.splice(i, 1);
    }
    doc.updated = Date.now();
    await DB.put('docs', doc);
    const y = document.querySelector('#doc .content').scrollTop;
    await openDoc(doc.id);
    document.querySelector('#doc .content').scrollTop = y;
  }
  $('docName').onchange = async () => {
    const v = $('docName').value.trim();
    if (!v) { $('docName').value = doc.name; return; }
    doc.name = v; doc.updated = Date.now(); await DB.put('docs', doc);
  };
  $('docName').onkeydown = (e) => { if (e.key === 'Enter') e.target.blur(); };
  $('docBack').onclick = async () => {
    if (doc && !doc.pages.length) await DB.del('docs', doc.id);
    doc = null; pickFor = 'new';
    show('home'); renderHome();
  };
  $('docMore').onclick = () => docMenu(doc, true);

  /* ================= doc menu ================= */
  let menuDoc = null;
  function docMenu(d, inside) {
    menuDoc = d;
    $('docSheetTitle').textContent = d.name;
    $('dmOpen').classList.toggle('hidden', inside);
    openSheet('docSheet');
  }
  $('dmOpen').onclick = () => { closeSheet(); openDoc(menuDoc.id); };
  $('dmShare').onclick = async () => { closeSheet(); doc = await DB.get('docs', menuDoc.id); openExport('share'); };
  $('dmRename').onclick = async () => {
    const v = await dialog({ title: 'إعادة التسمية', input: menuDoc.name, yes: 'حفظ' });
    if (!v) return;
    const d = await DB.get('docs', menuDoc.id); d.name = v; d.updated = Date.now(); await DB.put('docs', d);
    if (current === 'doc') { doc = d; $('docName').value = v; } else renderHome();
  };
  $('dmCopy').onclick = async () => {
    closeSheet();
    const d = await DB.get('docs', menuDoc.id);
    const nd = { id: uid(), name: d.name + ' (نسخة)', created: Date.now(), updated: Date.now(), pages: [] };
    for (const pid of d.pages) { const p = await DB.get('pages', pid); if (!p) continue; p.id = uid(); await DB.put('pages', p); nd.pages.push(p.id); }
    await DB.put('docs', nd);
    toast('تم إنشاء نسخة');
    if (current === 'doc') openDoc(nd.id); else renderHome();
  };
  $('dmDelete').onclick = async () => {
    const ok = await dialog({ title: 'حذف «' + menuDoc.name + '»؟', text: 'سيتم حذف المستند وكل صفحاته نهائياً.', yes: 'حذف', danger: true });
    if (!ok) return;
    const d = await DB.get('docs', menuDoc.id);
    for (const pid of d.pages) await DB.del('pages', pid);
    await DB.del('docs', d.id);
    toast('تم حذف المستند');
    doc = null; pickFor = 'new'; show('home'); renderHome();
  };

  /* ================= export ================= */
  const QUALITY = { high: { cap: 2400, q: 0.88 }, mid: { cap: 1700, q: 0.78 }, small: { cap: 1200, q: 0.62 } };
  const pref = { quality: 'mid', size: 'auto' };
  try { Object.assign(pref, JSON.parse(localStorage.getItem('exportPref') || '{}')); } catch (e) { }
  function segInit(id, key) {
    const seg = $(id);
    seg.querySelectorAll('button').forEach((b) => {
      b.classList.toggle('on', b.dataset.v === pref[key]);
      b.onclick = () => {
        pref[key] = b.dataset.v;
        seg.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b));
        try { localStorage.setItem('exportPref', JSON.stringify(pref)); } catch (e) { }
      };
    });
  }
  segInit('segQuality', 'quality'); segInit('segSize', 'size');
  let exportMode = 'save';
  function openExport(mode) {
    exportMode = mode;
    $('exportTitle').textContent = mode === 'share' ? 'مشاركة المستند' : 'حفظ المستند';
    $('fileName').value = doc.name;
    $('fileExt').textContent = '.pdf';
    $('estSize').textContent = pagesWord(doc.pages.length);
    openSheet('exportSheet');
  }
  $('saveBtn').onclick = () => openExport('save');
  $('shareBtn').onclick = () => openExport('share');
  $('fileName').onkeydown = (e) => { if (e.key === 'Enter') e.target.blur(); };
  async function takeName() {
    const v = $('fileName').value.trim();
    if (!v) { toast('اكتب اسماً للملف'); $('fileName').focus(); return false; }
    if (v !== doc.name) {
      doc.name = v; doc.updated = Date.now(); await DB.put('docs', doc);
      if (current === 'doc') $('docName').value = v;
    }
    return true;
  }
  $('exPdf').onclick = async () => { if (!(await takeName())) return; closeSheet(); exportDoc('pdf', exportMode); };
  $('exJpg').onclick = async () => { if (!(await takeName())) return; closeSheet(); exportDoc('jpg', exportMode); };

  const safeName = (s) => (s || 'NEXA Scan').replace(/[\\/:*?"<>|]+/g, ' ').trim().slice(0, 60) || 'NEXA Scan';

  async function renderPagesForExport(cfg) {
    const out = [];
    for (let i = 0; i < doc.pages.length; i++) {
      busy(true, 'جارٍ تجهيز الصفحة ' + (i + 1) + ' من ' + doc.pages.length + '…');
      await frame();
      const p = await DB.get('pages', doc.pages[i]);
      const c = await blobToCanvas(p.out, cfg.cap);
      const blob = await toBlob(c, cfg.q);
      out.push({ blob, width: c.width, height: c.height });
      c.width = 0;
    }
    return out;
  }

  async function exportDoc(kind, mode) {
    if (!doc || !doc.pages.length) return;
    const cfg = QUALITY[pref.quality] || QUALITY.mid;
    try {
      const pages = await renderPagesForExport(cfg);
      busy(true, 'جارٍ إنشاء الملف…');
      await frame();
      const base = safeName(doc.name);
      let files;
      if (kind === 'pdf') {
        const arr = [];
        for (const p of pages) arr.push({ jpeg: new Uint8Array(await p.blob.arrayBuffer()), width: p.width, height: p.height });
        const bytes = Scan.makePdf(arr, pref.size, doc.name);
        files = [{ name: base + '.pdf', blob: new Blob([bytes], { type: 'application/pdf' }), mime: 'application/pdf' }];
      } else {
        files = pages.map((p, i) => ({ name: base + (pages.length > 1 ? ' - ' + (i + 1) : '') + '.jpg', blob: p.blob, mime: 'image/jpeg' }));
      }
      await deliver(files, mode);
    } catch (e) {
      if (e && e.name === 'AbortError') { busy(false); return; }
      busy(false); toast('تعذّر إنشاء الملف');
    }
  }

  function b64(buf) {
    const bytes = new Uint8Array(buf); let s = '';
    for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    return btoa(s);
  }

  async function deliver(files, mode) {
    if (isAndroidApp) {
      const ids = [];
      for (const f of files) {
        const buf = await f.blob.arrayBuffer();
        const id = Android.beginFile(f.name, f.mime);
        const CH = 3 * 256 * 1024;
        for (let o = 0; o < buf.byteLength; o += CH) Android.appendChunk(id, b64(buf.slice(o, o + CH)));
        ids.push(id);
      }
      busy(false);
      const msg = Android.finishFiles(JSON.stringify(ids), mode);
      if (msg) toast(msg);
      return;
    }
    const fileObjs = files.map((f) => new File([f.blob], f.name, { type: f.mime }));
    const canShare = navigator.canShare && navigator.canShare({ files: fileObjs });
    busy(false);
    if (canShare && (mode === 'share' || isIOS)) {
      try { await navigator.share({ files: fileObjs, title: doc.name }); }
      catch (e) { if (e.name !== 'AbortError') downloadAll(files); }
      return;
    }
    if (mode === 'share' && !canShare) toast('المشاركة غير مدعومة في هذا المتصفح، تم تنزيل الملف');
    downloadAll(files);
  }
  function downloadAll(files) {
    files.forEach((f, i) => setTimeout(() => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(f.blob); a.download = f.name;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
    }, i * 400));
    toast(files.length > 1 ? 'تم تنزيل ' + files.length + ' صور' : 'تم تنزيل الملف');
  }

  /* ================= back button (Android) ================= */
  window.nexaBack = function () {
    if (dlgOpen) { dlgClose(false); return true; }
    if (openSheetEl) { closeSheet(); return true; }
    if ($('busy').classList.contains('on')) return true;
    if (current === 'crop') { $('cropBack').onclick(); return true; }
    if (current === 'edit') { $('editBack').onclick(); return true; }
    if (current === 'doc') { $('docBack').onclick(); return true; }
    return false;
  };

  /* ================= start ================= */
  DB.open().then(renderHome).catch(() => toast('تعذّر فتح التخزين'));
  if ('serviceWorker' in navigator && !isAndroidApp && location.protocol === 'https:') {
    navigator.serviceWorker.register('sw.js').catch(() => { });
  }
})();
